# Geometry score: eth3d-facade/A2-ma518_KT-exact-shape-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-exact-shape-orient`. Status counts: {'scored': 25, 'missing': 25, 'extent_limited': 1, 'phantom': 19, 'scale_reference': 0}.

**Key distances (25 scored):** median 18.97 in, p90 39.95 in, max 57.07 in; ≤2 in 20%, ≤4 in 20%, ≤6 in 20%; within the recon's own bound 56%.

**Scale:** KD ratio median 0.92598 (n=4, error -7.402 %), landmark Umeyama 1.0796. Alignment: {'metric_declared': False, 'method': 'given transform'}.

**Anchor:** ICP translation 1.6245 m [-0.0264, 0.0391, 1.6238], yaw -4.718°, tilt 0.513°.

**On truly observed elements:** 21 KDs, median 20.28 in, p90 41.36 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.3667 | -6.193 in | 0.207 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 17.4622 | 63.472 in | 0.242 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.8795 | -37.85 in | 0.28 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -8.5546 | -48.287 in | 0.28 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.8505 | -0.984 in | 0.28 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 2.7897 | -25.177 in | 0.28 | False | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.3249 | -10.437 in | 0.56 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -4.216 | 57.067 in | 0.355 | False | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -2.9925 | 41.358 in | 0.355 | False | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9819 | 0.941 in | 0.355 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.8168 | -28.008 in | 0.355 | False | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.2235 | -15.709 in | 0.71 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.7527 | 28.547 in | 0.37 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.5399 | 9.575 in | 0.37 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0262 | 0.575 in | 0.37 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.8006 | -30.512 in | 0.37 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.2128 | -18.972 in | 0.74 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6224 | -6.024 in | 0.619 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.7445 | -26.307 in | 0.619 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0575 | -0.618 in | 0.619 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.8018 | -33.425 in | 0.619 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.1221 | -20.283 in | 1.238 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.2398 | -12.811 in | 0.725 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.1623 | -15.598 in | 0.989 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.308 | -0.039 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.346 | -31.102 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -11.733 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 94.85 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 5.7292 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -112.03 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 5.7174 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 5.0985 |   |  |  | – / – |
| `opening.edge_s[rc:win2:left]` | phantom |  | -7.0021 |   |  |  | – / – |
| `opening.edge_s[rc:win2:right]` | phantom |  | -5.7191 |   |  |  | – / – |
| `opening.bottom[rc:win2]` | phantom |  | 0.8486 |   |  |  | – / – |
| `opening.top[rc:win2]` | phantom |  | 2.7756 |   |  |  | – / – |
| `opening.width[rc:win2]` | phantom |  | 1.283 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.1529 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 5.1176 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1558 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.7025 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.9647 |   |  |  | – / – |
| `opening.gap[win2~rc:win2]` | phantom |  | 1.5525 |   |  |  | – / – |
| `opening.gap[rc:win2~win3]` | phantom |  | 1.5031 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.4084 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 2%/13%/47% | 60%/92%/98% | 0.216 | 0.9995 | 0.0001 | observed, 0.9992, 0.0007 | 0.5177 | 0.0 |
| wall_face | 58856 | 2%/13%/44% | 51%/78%/85% | 0.2457 | 0.902 | 0.0162 | grazing, 0.8953, 0.0664 | 0.4978 | 0.0104 |
| ground_strip | 206971 | 5%/14%/40% | 13%/37%/64% | 0.0916 | 0.0 | 0.0916 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/0%/1% | 2%/9%/31% | 0.4392 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7176 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.4343, in own unknown voxels 0.9057, flagged generated 0.0.
