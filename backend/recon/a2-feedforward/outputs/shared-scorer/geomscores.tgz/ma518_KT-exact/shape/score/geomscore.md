# Geometry score: eth3d-facade/A2-ma518_KT-exact-shape vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-exact-shape`. Status counts: {'scored': 25, 'missing': 25, 'extent_limited': 1, 'phantom': 25, 'scale_reference': 0}.

**Key distances (25 scored):** median 17.33 in, p90 83.33 in, max 1373.47 in; ≤2 in 20%, ≤4 in 20%, ≤6 in 20%; within the recon's own bound 52%.

**Scale:** KD ratio median 0.77963 (n=2, error -22.037 %), landmark Umeyama 1.03671. Alignment: {'metric_declared': False, 'similarity_scale': 1.030407, 'method': 'similarity (unscaled cloud): camera centres -> GT cameras; scale error not meaningful', 'camera_rms_m': 0.1028, 'cameras': 16}.

**Anchor:** ICP translation 1.3573 m [0.0222, 0.0364, 1.3567], yaw -6.441°, tilt 0.227°.

**On truly observed elements:** 21 KDs, median 24.2 in, p90 106.38 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.3634 | -6.323 in | 0.22 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 10.2534 | -220.339 in | 0.274 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | 25.968 | 1373.469 in | 0.331 | False | grazing / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | 24.856 | 1267.091 in | 0.331 | False | grazing / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.902 | 1.043 in | 0.331 | True | grazing / observed |
| `opening.top[win2]` | scored | 3.4292 | 2.7628 | -26.236 in | 0.331 | False | grazing / observed |
| `opening.width[win2]` | scored | 1.59 | -1.112 | -106.378 in | 0.662 | False | grazing / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -4.4271 | 48.756 in | 0.352 | False | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.1448 | 35.362 in | 0.352 | False | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.979 | 0.827 in | 0.352 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.8729 | -25.799 in | 0.352 | False | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.2823 | -13.394 in | 0.704 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.863 | 24.205 in | 0.373 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.6084 | 6.878 in | 0.373 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0222 | 0.417 in | 0.373 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.839 | -29.0 in | 0.373 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.2546 | -17.327 in | 0.746 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.5779 | -7.776 in | 0.617 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.721 | -27.232 in | 0.617 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0518 | -0.843 in | 0.617 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.8233 | -32.579 in | 0.617 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.1431 | -19.457 in | 1.234 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.2818 | -11.157 in | 0.725 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.1863 | -14.654 in | 0.99 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.312 | 0.118 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.72 | -16.378 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | 6.4072 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -57.16 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 8.6998 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -133.94 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 28.466 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -85.84 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | 32.5649 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | -104.57 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 2.2926 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 19.7662 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 4.0988 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 4.0027 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.1422 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 5.1018 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1424 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.7061 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.9596 |   |  |  | – / – |
| `opening.edge_s[rc:win2:left]` | phantom |  | 23.494 |   |  |  | – / – |
| `opening.edge_s[rc:win2:right]` | phantom |  | 22.3384 |   |  |  | – / – |
| `opening.bottom[rc:win2]` | phantom |  | 0.869 |   |  |  | – / – |
| `opening.top[rc:win2]` | phantom |  | 2.7928 |   |  |  | – / – |
| `opening.width[rc:win2]` | phantom |  | -1.1556 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.4212 |   |  |  | – / – |
| `opening.gap[rc:door~rc:win2]` | phantom |  | 18.3922 |   |  |  | – / – |
| `opening.gap[rc:win2~win2]` | phantom |  | 3.6296 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 2%/13%/51% | 61%/93%/98% | 0.1106 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3134 | 0.0 |
| wall_face | 58856 | 2%/13%/47% | 52%/80%/86% | 0.1604 | 0.902 | 0.0197 | grazing, 0.8953, 0.0664 | 0.315 | 0.0 |
| ground_strip | 206971 | 5%/15%/51% | 14%/39%/65% | 0.0939 | 0.0 | 0.0939 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/1%/3% | 2%/9%/29% | 0.4048 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6627 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.3385, in own unknown voxels 0.9067, flagged generated 0.0.
