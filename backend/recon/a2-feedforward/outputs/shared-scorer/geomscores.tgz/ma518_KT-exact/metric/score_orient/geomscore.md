# Geometry score: eth3d-facade/A2-ma518_KT-exact-metric-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-exact-metric-orient`. Status counts: {'scored': 20, 'missing': 30, 'extent_limited': 1, 'phantom': 63, 'scale_reference': 0}.

**Key distances (20 scored):** median 19.68 in, p90 37.2 in, max 65.93 in; ≤2 in 20%, ≤4 in 20%, ≤6 in 25%; within the recon's own bound 65%.

**Scale:** KD ratio median 0.70296 (n=2, error -29.704 %), landmark Umeyama 0.70935. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 1.3675 m [0.102, 0.0317, 1.3633], yaw -2.871°, tilt 0.522°.

**On truly observed elements:** 16 KDs, median 20.94 in, p90 41.78 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.3349 | -7.445 in | 0.224 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 16.5539 | 27.713 in | 0.96 | True | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -3.9908 | 65.933 in | 0.49 | False | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -2.8362 | 47.512 in | 0.49 | False | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9755 | 0.689 in | 0.49 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.736 | -31.189 in | 0.49 | False | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.1546 | -18.421 in | 0.98 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.6545 | 32.413 in | 0.428 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.4919 | 11.465 in | 0.428 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0101 | -0.059 in | 0.428 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.727 | -33.409 in | 0.428 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.1626 | -20.949 in | 0.856 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6306 | -5.701 in | 0.702 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.7362 | -26.634 in | 0.702 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0329 | -1.587 in | 0.702 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.735 | -36.055 in | 0.702 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.1056 | -20.933 in | 1.404 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.1817 | -15.098 in | 0.918 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.1225 | -17.165 in | 1.13 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.308 | -0.039 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.23 | -35.669 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -42.4273 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -134.53 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -31.6983 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -97.07 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -31.3097 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 126.95 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -29.0894 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 141.52 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | -17.8302 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | 64.2 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | -11.393 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | 91.28 |   |  |  | – / – |
| `corner.s[rc:c7]` | phantom |  | 5.1609 |   |  |  | – / – |
| `corner.turn[rc:c7]` | phantom |  | -100.52 |   |  |  | – / – |
| `corner.s[rc:c8]` | phantom |  | 8.6539 |   |  |  | – / – |
| `corner.turn[rc:c8]` | phantom |  | -144.91 |   |  |  | – / – |
| `corner.s[rc:c9]` | phantom |  | 13.2644 |   |  |  | – / – |
| `corner.turn[rc:c9]` | phantom |  | -119.44 |   |  |  | – / – |
| `corner.s[rc:c10]` | phantom |  | 16.2808 |   |  |  | – / – |
| `corner.turn[rc:c10]` | phantom |  | -102.22 |   |  |  | – / – |
| `corner.s[rc:c11]` | phantom |  | 20.755 |   |  |  | – / – |
| `corner.turn[rc:c11]` | phantom |  | -136.84 |   |  |  | – / – |
| `corner.s[rc:c12]` | phantom |  | 25.4666 |   |  |  | – / – |
| `corner.turn[rc:c12]` | phantom |  | -112.97 |   |  |  | – / – |
| `corner.s[rc:c13]` | phantom |  | 28.8717 |   |  |  | – / – |
| `corner.turn[rc:c13]` | phantom |  | -135.18 |   |  |  | – / – |
| `corner.s[rc:c14]` | phantom |  | 31.4348 |   |  |  | – / – |
| `corner.turn[rc:c14]` | phantom |  | -113.83 |   |  |  | – / – |
| `corner.s[rc:c15]` | phantom |  | 33.3488 |   |  |  | – / – |
| `corner.turn[rc:c15]` | phantom |  | -126.41 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 6.911 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 10.729 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 0.3886 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 2.2203 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 11.2592 |   |  |  | – / – |
| `wall.length[rc:w6]` | phantom |  | 6.4373 |   |  |  | – / – |
| `wall.length[rc:w8]` | phantom |  | 3.493 |   |  |  | – / – |
| `wall.length[rc:w9]` | phantom |  | 4.6105 |   |  |  | – / – |
| `wall.length[rc:w10]` | phantom |  | 3.0164 |   |  |  | – / – |
| `wall.length[rc:w11]` | phantom |  | 4.4743 |   |  |  | – / – |
| `wall.length[rc:w12]` | phantom |  | 4.7117 |   |  |  | – / – |
| `wall.length[rc:w13]` | phantom |  | 3.405 |   |  |  | – / – |
| `wall.length[rc:w14]` | phantom |  | 2.5632 |   |  |  | – / – |
| `wall.length[rc:w15]` | phantom |  | 1.914 |   |  |  | – / – |
| `wall.length[rc:w16]` | phantom |  | 10.4145 |   |  |  | – / – |
| `opening.edge_s[rc:win2:left]` | phantom |  | -48.671 |   |  |  | – / – |
| `opening.edge_s[rc:win2:right]` | phantom |  | -49.5167 |   |  |  | – / – |
| `opening.bottom[rc:win2]` | phantom |  | 0.9739 |   |  |  | – / – |
| `opening.top[rc:win2]` | phantom |  | 2.4374 |   |  |  | – / – |
| `opening.width[rc:win2]` | phantom |  | -0.8457 |   |  |  | – / – |
| `opening.edge_s[rc:win1:left]` | phantom |  | -46.8621 |   |  |  | – / – |
| `opening.edge_s[rc:win1:right]` | phantom |  | -47.6518 |   |  |  | – / – |
| `opening.bottom[rc:win1]` | phantom |  | 0.9864 |   |  |  | – / – |
| `opening.top[rc:win1]` | phantom |  | 2.3805 |   |  |  | – / – |
| `opening.width[rc:win1]` | phantom |  | -0.7897 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 13.6754 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 15.5879 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1989 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.5218 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.9125 |   |  |  | – / – |
| `opening.gap[rc:win2~rc:win1]` | phantom |  | 2.6546 |   |  |  | – / – |
| `opening.gap[rc:win1~win3]` | phantom |  | 43.661 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 11.9392 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 4%/22%/65% | 60%/94%/98% | 0.1567 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4926 | 0.0 |
| wall_face | 58856 | 4%/20%/59% | 51%/81%/86% | 0.1998 | 0.902 | 0.02 | grazing, 0.8953, 0.0664 | 0.4864 | 0.0202 |
| ground_strip | 206971 | 6%/15%/44% | 14%/39%/66% | 0.0956 | 0.0 | 0.0956 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/0%/3% | 0%/5%/26% | 0.3869 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6733 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.3784, in own unknown voxels 0.8962, flagged generated 0.0.
