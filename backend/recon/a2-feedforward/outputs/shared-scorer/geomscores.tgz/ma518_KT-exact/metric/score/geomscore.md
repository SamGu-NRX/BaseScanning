# Geometry score: eth3d-facade/A2-ma518_KT-exact-metric vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-exact-metric`. Status counts: {'scored': 25, 'missing': 25, 'extent_limited': 1, 'phantom': 34, 'scale_reference': 0}.

**Key distances (25 scored):** median 17.86 in, p90 34.99 in, max 51.85 in; ≤2 in 16%, ≤4 in 16%, ≤6 in 24%; within the recon's own bound 64%.

**Scale:** KD ratio median 1.12569 (n=4, error 12.569 %), landmark Umeyama 1.08533. Alignment: {'metric_declared': True, 'similarity_scale': 1.030407, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -2.951, 'camera_rms_m': 0.3385, 'cameras': 16}.

**Anchor:** ICP translation 1.5375 m [0.0082, 0.0345, 1.5371], yaw -3.854°, tilt 0.216°.

**On truly observed elements:** 21 KDs, median 21.82 in, p90 35.03 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.3308 | -7.606 in | 0.221 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 16.4743 | 24.579 in | 0.956 | True | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.2483 | -13.0 in | 0.606 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -8.0195 | -27.22 in | 0.606 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.8557 | -0.78 in | 0.606 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 2.6774 | -29.598 in | 0.606 | False | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.2288 | -14.22 in | 1.212 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -6.5552 | -35.028 in | 0.563 | False | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -5.3601 | -51.854 in | 0.563 | False | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.8507 | -4.224 in | 0.563 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.6635 | -34.043 in | 0.563 | False | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.1951 | -16.827 in | 1.126 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.6129 | 34.051 in | 0.442 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.4724 | 12.232 in | 0.442 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0125 | 0.035 in | 0.442 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.6881 | -34.941 in | 0.442 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.1405 | -21.819 in | 0.884 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6325 | -5.626 in | 0.728 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.7041 | -27.898 in | 0.728 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0392 | -1.339 in | 0.728 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.6922 | -37.74 in | 0.728 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.0716 | -22.272 in | 1.456 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.4643 | -7.807 in | 1.169 | True | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.1049 | -17.858 in | 1.17 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.308 | -0.039 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.524 | -24.094 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -23.816 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -87.67 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -17.5342 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 69.24 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -17.128 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 109.46 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -11.4023 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 92.7 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | 5.072 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | -92.32 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | 5.9393 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | -109.84 |   |  |  | – / – |
| `corner.s[rc:c7]` | phantom |  | 8.2449 |   |  |  | – / – |
| `corner.turn[rc:c7]` | phantom |  | 136.02 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 24.0766 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 6.2819 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 0.4061 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 5.7258 |   |  |  | – / – |
| `wall.length[rc:w6]` | phantom |  | 0.8673 |   |  |  | – / – |
| `wall.length[rc:w7]` | phantom |  | 2.3058 |   |  |  | – / – |
| `wall.length[rc:w8]` | phantom |  | 3.9117 |   |  |  | – / – |
| `opening.edge_s[rc:win3:left]` | phantom |  | -3.9287 |   |  |  | – / – |
| `opening.edge_s[rc:win3:right]` | phantom |  | -2.7852 |   |  |  | – / – |
| `opening.bottom[rc:win3]` | phantom |  | 0.9738 |   |  |  | – / – |
| `opening.top[rc:win3]` | phantom |  | 2.7012 |   |  |  | – / – |
| `opening.width[rc:win3]` | phantom |  | 1.1435 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.0335 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 4.9112 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1763 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.553 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.8777 |   |  |  | – / – |
| `opening.gap[win3~rc:win3]` | phantom |  | 1.4314 |   |  |  | – / – |
| `opening.gap[rc:win3~win4]` | phantom |  | 1.1723 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.3294 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 3%/16%/53% | 59%/93%/98% | 0.2191 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.5141 | 0.0 |
| wall_face | 58856 | 3%/15%/49% | 51%/80%/86% | 0.2471 | 0.902 | 0.0153 | grazing, 0.8953, 0.0664 | 0.5019 | 0.0178 |
| ground_strip | 206971 | 5%/14%/55% | 14%/40%/66% | 0.0888 | 0.0 | 0.0888 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/0%/4% | 1%/7%/30% | 0.4306 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7183 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.4282, in own unknown voxels 0.8917, flagged generated 0.0.
