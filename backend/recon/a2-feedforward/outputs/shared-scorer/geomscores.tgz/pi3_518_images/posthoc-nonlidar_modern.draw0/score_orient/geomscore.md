# Geometry score: eth3d-facade/A2-pi3_518_images-posthoc-nonlidar_modern.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-posthoc-nonlidar_modern.draw0-orient`. Status counts: {'scored': 42, 'missing': 8, 'extent_limited': 1, 'phantom': 6, 'scale_reference': 0}.

**Key distances (41 scored):** median 3.13 in, p90 16.09 in, max 44.59 in; ≤2 in 27%, ≤4 in 61%, ≤6 in 68%; within the recon's own bound 98%.

**Scale:** KD ratio median 0.96297 (n=11, error -3.703 %), landmark Umeyama 0.96381. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.0598 m [0.047, 0.0068, 0.0364], yaw 0.088°, tilt 0.435°.

**On truly observed elements:** 31 KDs, median 3.27 in, p90 16.09 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4509 | -2.878 in | 0.157 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.9632 | -2.154 in | 0.523 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 92.78 | 1.67 deg | 41.7967 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.3524 | -19.591 in | 0.894 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.5378 | -0.189 in | 0.62 | True | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -11.764 | 17.811 in | 0.52 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.25 | 16.094 in | 0.52 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 0.97 | 2.189 in | 0.52 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.3152 | -2.874 in | 0.52 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.514 | -1.717 in | 1.04 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.5613 | 14.047 in | 0.45 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.0254 | 11.917 in | 0.45 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9162 | 1.602 in | 0.45 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.3344 | -3.732 in | 0.45 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5359 | -2.13 in | 0.9 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.4424 | 8.783 in | 0.27 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.8669 | 6.933 in | 0.27 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9401 | -0.705 in | 0.27 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.3926 | -5.339 in | 0.27 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5755 | -1.85 in | 0.54 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4044 | 2.89 in | 0.3 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.767 | 0.634 in | 0.3 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9788 | -1.291 in | 0.3 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.4193 | -6.154 in | 0.3 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6374 | -2.256 in | 0.6 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6786 | -3.811 in | 0.296 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.2503 | -6.394 in | 0.296 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0231 | -1.972 in | 0.296 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.4662 | -7.268 in | 0.296 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5717 | -2.583 in | 0.592 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 7.3455 | 3.272 in | 1.236 | True | unobserved / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 10.5847 | 44.587 in | 1.236 | True | unobserved / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.1108 | -3.969 in | 1.236 | True | unobserved / observed |
| `opening.top[door]` | scored | 4.074 | 4.1225 | 1.909 in | 1.236 | True | unobserved / observed |
| `opening.width[door]` | scored | 2.1898 | 3.2392 | 41.315 in | 2.472 | True | unobserved / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.6887 | -2.047 in | 0.97 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.583 | -3.134 in | 0.72 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.4625 | -4.043 in | 0.57 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.4456 | -4.445 in | 0.596 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 5.0952 | 9.665 in | 1.532 | True | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.336 | 1.063 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 0.351 | 1.417 in | 0.05 | True | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.229 | -35.709 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -12.3892 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 90.62 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 6.5009 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -120.81 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 7.4797 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 7.5705 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 56%/95%/100% | 67%/97%/100% | 0.7007 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.6114 | 0.0 |
| wall_face | 58856 | 49%/86%/94% | 59%/88%/95% | 0.6461 | 0.902 | 0.0084 | grazing, 0.8953, 0.0664 | 0.5472 | 0.0 |
| ground_strip | 206971 | 15%/44%/70% | 12%/34%/67% | 0.1158 | 0.0 | 0.1158 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 16%/29%/40% | 8%/30%/43% | 0.6402 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6931 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0506, in own unknown voxels 0.6689, flagged generated 0.0.
