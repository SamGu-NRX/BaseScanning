# Geometry score: eth3d-facade/A2-pi3_518_images-posthoc-nonlidar_modern.draw0 vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-posthoc-nonlidar_modern.draw0`. Status counts: {'scored': 42, 'missing': 8, 'extent_limited': 1, 'phantom': 15, 'scale_reference': 0}.

**Key distances (41 scored):** median 3.46 in, p90 12.34 in, max 43.22 in; ≤2 in 32%, ≤4 in 56%, ≤6 in 71%; within the recon's own bound 95%.

**Scale:** KD ratio median 0.97142 (n=11, error -2.858 %), landmark Umeyama 0.97096. Alignment: {'metric_declared': True, 'similarity_scale': 1.038536, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.711, 'camera_rms_m': 0.5029, 'cameras': 16}.

**Anchor:** ICP translation 0.0676 m [0.0307, 0.0123, 0.0589], yaw -0.706°, tilt 0.671°.

**On truly observed elements:** 31 KDs, median 3.46 in, p90 11.99 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4439 | -3.154 in | 0.209 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.9522 | -2.587 in | 0.626 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 91.13 | 0.02 deg | 44.8852 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.292 | -21.969 in | 0.996 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.4327 | -4.327 in | 0.65 | True | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -11.9031 | 12.335 in | 0.554 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.3542 | 11.992 in | 0.554 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 0.9542 | 1.567 in | 0.554 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.3255 | -2.469 in | 0.554 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5489 | -0.343 in | 1.108 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.6584 | 10.224 in | 0.507 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.0954 | 9.161 in | 0.507 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9026 | 1.067 in | 0.507 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.3413 | -3.461 in | 0.507 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.563 | -1.063 in | 1.014 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.4955 | 6.693 in | 0.326 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.9011 | 5.587 in | 0.326 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.929 | -1.142 in | 0.326 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.3945 | -5.264 in | 0.326 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5944 | -1.106 in | 0.652 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4277 | 1.972 in | 0.355 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7817 | 0.055 in | 0.355 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9703 | -1.626 in | 0.355 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.4151 | -6.319 in | 0.355 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.646 | -1.917 in | 0.71 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6659 | -4.311 in | 0.346 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.2352 | -6.988 in | 0.346 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0168 | -2.22 in | 0.346 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.4554 | -7.693 in | 0.346 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5693 | -2.677 in | 0.692 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 7.1674 | -3.74 in | 1.257 | True | unobserved / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 10.455 | 39.48 in | 1.257 | True | unobserved / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.0971 | -4.508 in | 1.257 | True | unobserved / observed |
| `opening.top[door]` | scored | 4.074 | 4.1168 | 1.685 in | 1.257 | True | unobserved / observed |
| `opening.width[door]` | scored | 2.1898 | 3.2876 | 43.22 in | 2.514 | True | unobserved / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.6958 | -1.768 in | 1.061 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.5999 | -2.469 in | 0.833 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.4734 | -3.614 in | 0.681 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.4476 | -4.366 in | 0.701 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 4.9322 | 3.248 in | 1.603 | True | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.352 | 1.693 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 0.933 | 24.331 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.351 | -30.906 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -33.8894 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 146.31 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -32.2265 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 122.36 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -19.9765 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 59.68 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -12.3398 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 91.28 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | 6.3849 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | -120.56 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 1.9941 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 1.663 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 12.25 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 7.6367 |   |  |  | – / – |
| `wall.length[rc:w7]` | phantom |  | 7.2078 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 46%/90%/100% | 68%/97%/100% | 0.7665 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.6533 | 0.0 |
| wall_face | 58856 | 41%/82%/94% | 59%/88%/95% | 0.698 | 0.902 | 0.0093 | grazing, 0.8953, 0.0664 | 0.5853 | 0.0 |
| ground_strip | 206971 | 18%/45%/69% | 12%/34%/67% | 0.0954 | 0.0 | 0.0954 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 8%/26%/46% | 9%/29%/47% | 0.6733 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7308 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0407, in own unknown voxels 0.6699, flagged generated 0.0.
