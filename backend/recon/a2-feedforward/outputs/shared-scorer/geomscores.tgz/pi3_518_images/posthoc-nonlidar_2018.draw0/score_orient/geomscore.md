# Geometry score: eth3d-facade/A2-pi3_518_images-posthoc-nonlidar_2018.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-posthoc-nonlidar_2018.draw0-orient`. Status counts: {'scored': 45, 'missing': 4, 'extent_limited': 2, 'phantom': 6, 'scale_reference': 0}.

**Key distances (43 scored):** median 5.27 in, p90 17.76 in, max 292.76 in; ≤2 in 28%, ≤4 in 44%, ≤6 in 58%; within the recon's own bound 88%.

**Scale:** KD ratio median 0.96434 (n=12, error -3.566 %), landmark Umeyama 0.96416. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.1025 m [0.0821, 0.0008, 0.0613], yaw -0.192°, tilt 0.414°.

**On truly observed elements:** 31 KDs, median 3.75 in, p90 13.26 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.465 | -2.323 in | 0.186 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.8825 | -5.331 in | 0.578 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 89.62 | -1.49 deg | 43.5914 | True | – / – |
| `corner.s[c2]` | scored | 6.5604 | 6.2913 | -10.594 in | 0.707 | True | – / – |
| `corner.turn[c2]` | scored | -91.08 | -83.92 | 7.16 deg | 50.4281 | True | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.351 | -19.646 in | 0.952 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.4088 | -5.268 in | 0.62 | True | – / – |
| `wall.length[w3]` | extent_limited | 4.9485 | 9.5941 | 182.899 in | 1.21 | False | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -11.8468 | 14.551 in | 0.545 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.3221 | 13.256 in | 0.545 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 0.9624 | 1.89 in | 0.545 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.3137 | -2.933 in | 0.545 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5247 | -1.295 in | 1.09 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.6257 | 11.512 in | 0.479 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.0823 | 9.677 in | 0.479 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9122 | 1.445 in | 0.479 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.3339 | -3.752 in | 0.479 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5434 | -1.835 in | 0.958 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.4957 | 6.685 in | 0.299 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.9159 | 5.004 in | 0.299 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9397 | -0.72 in | 0.299 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.393 | -5.323 in | 0.299 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5798 | -1.681 in | 0.598 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4517 | 1.028 in | 0.329 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8139 | -1.213 in | 0.329 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9821 | -1.161 in | 0.329 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.4202 | -6.118 in | 0.329 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6378 | -2.24 in | 0.658 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6301 | -5.72 in | 0.322 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.2223 | -7.496 in | 0.322 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0299 | -1.705 in | 0.322 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.4672 | -7.228 in | 0.322 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5922 | -1.776 in | 0.644 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 6.8079 | -17.894 in | 0.498 | True | observed / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 8.7902 | -26.063 in | 0.498 | False | observed / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.265 | 2.102 in | 0.498 | True | observed / observed |
| `opening.top[door]` | scored | 4.074 | 3.8532 | -8.693 in | 0.498 | True | observed / observed |
| `opening.width[door]` | scored | 2.1898 | 1.9823 | -8.169 in | 0.996 | True | observed / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.6964 | -1.744 in | 1.024 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.5866 | -2.992 in | 0.778 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.4642 | -3.976 in | 0.628 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.444 | -4.508 in | 0.651 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 4.5856 | -10.398 in | 0.82 | True | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 2.13 | 71.693 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 7.751 | 292.756 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | scored | 0.749 | 0.311 | -17.244 in | 0.05 | False | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.291 | -33.268 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -19.2869 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 101.25 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -12.4685 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 91.93 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 2.2969 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 6.8184 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 45%/89%/100% | 67%/96%/100% | 0.6842 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.588 | 0.0 |
| wall_face | 58856 | 40%/80%/94% | 59%/88%/95% | 0.634 | 0.902 | 0.0078 | grazing, 0.8953, 0.0664 | 0.5332 | 0.0 |
| ground_strip | 206971 | 16%/46%/71% | 12%/35%/69% | 0.1061 | 0.0 | 0.1061 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 11%/26%/39% | 10%/26%/42% | 0.619 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6653 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0444, in own unknown voxels 0.6663, flagged generated 0.0.
