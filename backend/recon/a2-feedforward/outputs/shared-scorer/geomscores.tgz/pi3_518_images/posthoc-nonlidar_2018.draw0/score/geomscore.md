# Geometry score: eth3d-facade/A2-pi3_518_images-posthoc-nonlidar_2018.draw0 vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-posthoc-nonlidar_2018.draw0`. Status counts: {'scored': 1, 'missing': 49, 'extent_limited': 1, 'phantom': 0, 'scale_reference': 0}.

**Key distances (1 scored):** median 2.81 in, p90 2.81 in, max 2.81 in; ≤2 in 0%, ≤4 in 100%, ≤6 in 100%; within the recon's own bound 100%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama None. Alignment: {'metric_declared': True, 'similarity_scale': 1.040544, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.896, 'camera_rms_m': 0.5194, 'cameras': 16}.

**Anchor:** ICP translation 0.1477 m [0.1205, -0.0251, 0.0817], yaw -25.6°, tilt 0.6°.

**On truly observed elements:** 1 KDs, median 2.81 in, p90 2.81 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4527 | -2.807 in | 0.242 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 1.5038 | -564.811 in | 0.434 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | missing | -2.4778 |  |   |  |  | – / observed |
| `opening.edge_s[win4:right]` | missing | -0.7831 |  |   |  |  | – / observed |
| `opening.bottom[win4]` | missing | 1.0116 |  |   |  |  | – / observed |
| `opening.top[win4]` | missing | 3.5756 |  |   |  |  | – / observed |
| `opening.width[win4]` | missing | 1.6947 |  |   |  |  | – / observed |
| `opening.edge_s[win5:left]` | missing | 0.7754 |  |   |  |  | – / observed |
| `opening.edge_s[win5:right]` | missing | 2.4127 |  |   |  |  | – / observed |
| `opening.bottom[win5]` | missing | 1.0732 |  |   |  |  | – / observed |
| `opening.top[win5]` | missing | 3.6508 |  |   |  |  | – / observed |
| `opening.width[win5]` | missing | 1.6373 |  |   |  |  | – / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 6%/12%/26% | 67%/96%/100% | 0.265 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.2733 | 0.0 |
| wall_face | 58856 | 5%/12%/24% | 59%/88%/96% | 0.2871 | 0.902 | 0.0216 | grazing, 0.8953, 0.0664 | 0.2808 | 0.0 |
| ground_strip | 206971 | 10%/26%/39% | 12%/30%/64% | 0.0595 | 0.0 | 0.0595 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/1%/19% | 7%/27%/42% | 0.4934 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.5972 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.1893, in own unknown voxels 0.8018, flagged generated 0.0.
