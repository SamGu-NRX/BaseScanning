# Geometry score: eth3d-facade/A2-pi3_518_images-posthoc-exact-orient vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-posthoc-exact-orient`. Status counts: {'scored': 47, 'missing': 2, 'extent_limited': 2, 'phantom': 3, 'scale_reference': 0}.

**Key distances (45 scored):** median 1.03 in, p90 8.84 in, max 31.65 in; ≤2 in 62%, ≤4 in 82%, ≤6 in 84%; within the recon's own bound 89%.

**Scale:** KD ratio median 0.9995 (n=12, error -0.05 %), landmark Umeyama 0.99712. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.0624 m [-0.0253, 0.0082, 0.0565], yaw -0.127°, tilt 0.448°.

**On truly observed elements:** 31 KDs, median 0.77 in, p90 2.94 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5045 | -0.768 in | 0.151 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 3.1282 | 4.343 in | 0.527 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 94.42 | 3.31 deg | 42.4273 | True | – / – |
| `corner.s[c2]` | scored | 6.5604 | 6.654 | 3.685 in | 0.698 | True | – / – |
| `corner.turn[c2]` | scored | -91.08 | -96.96 | -5.88 deg | 51.474 | True | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 16.0546 | 8.055 in | 0.914 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.5257 | -0.664 in | 0.634 | True | – / – |
| `wall.length[w3]` | extent_limited | 4.9485 | 9.8939 | 194.7 in | 1.256 | False | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.2187 | -0.091 in | 0.531 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.6461 | 0.5 in | 0.531 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0032 | 3.496 in | 0.531 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.4392 | 2.008 in | 0.531 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5726 | 0.591 in | 1.062 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.8923 | 1.016 in | 0.459 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.2969 | 1.228 in | 0.459 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9478 | 2.846 in | 0.459 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4597 | 1.201 in | 0.459 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5954 | 0.213 in | 0.918 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.6528 | 0.5 in | 0.271 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.0163 | 1.051 in | 0.271 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9731 | 0.594 in | 0.271 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.5207 | -0.295 in | 0.271 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6365 | 0.551 in | 0.542 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4971 | -0.76 in | 0.303 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7962 | -0.516 in | 0.303 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0139 | 0.091 in | 0.303 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.5491 | -1.043 in | 0.303 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7009 | 0.244 in | 0.606 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7054 | -2.756 in | 0.299 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3381 | -2.937 in | 0.299 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0604 | -0.504 in | 0.299 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.5983 | -2.067 in | 0.299 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6327 | -0.181 in | 0.598 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 7.4316 | 6.661 in | 0.567 | True | partial / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 9.6477 | 7.697 in | 0.567 | True | partial / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.2347 | 0.909 in | 0.567 | True | partial / observed |
| `opening.top[door]` | scored | 4.074 | 4.0571 | -0.665 in | 0.567 | True | partial / observed |
| `opening.width[door]` | scored | 2.1898 | 2.2161 | 1.035 in | 1.134 | True | partial / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.7538 | 0.516 in | 0.99 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6441 | -0.728 in | 0.73 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5192 | -1.811 in | 0.574 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5016 | -2.24 in | 0.602 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 5.0935 | 9.598 in | 0.866 | True | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.393 | 3.307 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 0.328 | 0.512 in | 0.05 | True | – / – |
| `facing.depth[w3@6.68]` | scored | 0.749 | 0.313 | -17.165 in | 0.05 | False | – / – |
| `facing.depth[w3@6.93]` | scored | 0.749 | 0.313 | -17.165 in | 0.05 | False | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | scored | 0.708 | 0.309 | -15.709 in | 0.05 | False | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.332 | -31.654 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -12.9264 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 90.05 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 6.1115 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 60%/97%/100% | 74%/99%/100% | 0.7256 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.6443 | 0.0 |
| wall_face | 58856 | 53%/91%/96% | 67%/94%/97% | 0.6578 | 0.902 | 0.0056 | grazing, 0.8953, 0.0664 | 0.5735 | 0.0 |
| ground_strip | 206971 | 14%/42%/65% | 11%/34%/63% | 0.1134 | 0.0 | 0.1134 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 9%/29%/42% | 10%/28%/70% | 0.7017 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7288 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0494, in own unknown voxels 0.6731, flagged generated 0.0.
