# Geometry score: eth3d-facade/A2-pi3_518_images-shape vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-shape`. Status counts: {'scored': 38, 'missing': 12, 'extent_limited': 1, 'phantom': 6, 'scale_reference': 0}.

**Key distances (38 scored):** median 1.48 in, p90 20.19 in, max 106.51 in; ≤2 in 58%, ≤4 in 76%, ≤6 in 82%; within the recon's own bound 87%.

**Scale:** KD ratio median 1.00186 (n=9, error 0.186 %), landmark Umeyama 1.0011. Alignment: {'metric_declared': False, 'similarity_scale': 18.179303, 'method': 'similarity (unscaled cloud): camera centres -> GT cameras; scale error not meaningful', 'camera_rms_m': 0.2977, 'cameras': 16}.

**Anchor:** ICP translation 0.0841 m [-0.0428, 0.0042, 0.0723], yaw -0.609°, tilt 0.663°.

**On truly observed elements:** 31 KDs, median 1.43 in, p90 13.16 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.509 | -0.591 in | 0.209 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.8383 | -0.461 in | 0.254 | True | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.3201 | -4.083 in | 0.216 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.7257 | -2.634 in | 0.216 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 0.9959 | 3.209 in | 0.216 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.4481 | 2.358 in | 0.216 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5944 | 1.449 in | 0.432 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.9537 | -1.402 in | 0.25 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.3417 | -0.535 in | 0.25 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9435 | 2.677 in | 0.25 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4675 | 1.508 in | 0.25 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.612 | 0.866 in | 0.5 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.6874 | -0.862 in | 0.161 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.0395 | 0.138 in | 0.161 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9723 | 0.563 in | 0.161 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.5272 | -0.039 in | 0.161 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6479 | 1.0 in | 0.322 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.514 | -1.425 in | 0.286 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8083 | -0.992 in | 0.286 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0165 | 0.193 in | 0.286 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.5535 | -0.87 in | 0.286 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7057 | 0.433 in | 0.572 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6939 | -3.209 in | 0.285 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3244 | -3.476 in | 0.285 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0663 | -0.272 in | 0.285 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6003 | -1.988 in | 0.285 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6305 | -0.268 in | 0.57 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 4.557 | -106.512 in | 0.805 | False | unobserved / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 7.1131 | -92.091 in | 0.805 | False | unobserved / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.059 | -6.008 in | 0.805 | True | unobserved / observed |
| `opening.top[door]` | scored | 4.074 | 4.4082 | 13.157 in | 0.805 | True | unobserved / observed |
| `opening.width[door]` | scored | 2.1898 | 2.5561 | 14.421 in | 1.61 | True | unobserved / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.772 | 1.232 in | 0.466 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6543 | -0.327 in | 0.411 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5255 | -1.563 in | 0.447 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5022 | -2.217 in | 0.571 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 2.2326 | -103.035 in | 1.09 | False | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.411 | 4.016 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.281 | -33.661 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -12.8789 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 91.4 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 2.9594 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 41.69 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 6.6263 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 5.8517 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 52%/94%/100% | 74%/99%/100% | 0.7689 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.6921 | 0.0 |
| wall_face | 58856 | 46%/87%/97% | 67%/95%/97% | 0.692 | 0.902 | 0.0053 | grazing, 0.8953, 0.0664 | 0.6118 | 0.0 |
| ground_strip | 206971 | 16%/44%/66% | 11%/33%/63% | 0.0961 | 0.0 | 0.0961 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 11%/29%/43% | 10%/29%/71% | 0.7216 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7791 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0321, in own unknown voxels 0.6791, flagged generated 0.0.
