# Geometry score: eth3d-facade/A2-pi3_518_images-shape-orient vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-shape-orient`. Status counts: {'scored': 36, 'missing': 13, 'extent_limited': 2, 'phantom': 0, 'scale_reference': 0}.

**Key distances (34 scored):** median 1.42 in, p90 16.66 in, max 283.23 in; ≤2 in 62%, ≤4 in 82%, ≤6 in 82%; within the recon's own bound 82%.

**Scale:** KD ratio median 1.0079 (n=8, error 0.79 %), landmark Umeyama 1.00509. Alignment: {'metric_declared': False, 'method': 'given transform'}.

**Anchor:** ICP translation 0.0886 m [-0.0218, -0.0011, 0.0859], yaw -0.473°, tilt 0.438°.

**On truly observed elements:** 21 KDs, median 0.87 in, p90 2.01 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5149 | -0.358 in | 0.192 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 3.0434 | 1.004 in | 0.232 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 90.24 | -0.87 deg | 13.9283 | True | – / – |
| `corner.s[c2]` | scored | 6.5604 | 6.6478 | 3.441 in | 0.245 | True | – / – |
| `corner.turn[c2]` | scored | -91.08 | -94.03 | -2.95 deg | 15.323 | True | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 11.3599 | -176.776 in | 0.216 | False | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.6044 | 2.436 in | 0.248 | True | – / – |
| `wall.length[w3]` | extent_limited | 4.9485 | 10.7627 | 228.906 in | 0.274 | False | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.6854 | -0.783 in | 0.141 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.0379 | 0.201 in | 0.141 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9836 | 1.008 in | 0.141 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.5411 | 0.508 in | 0.141 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6475 | 0.984 in | 0.282 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5119 | -1.343 in | 0.268 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8044 | -0.839 in | 0.268 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0238 | 0.48 in | 0.268 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.5651 | -0.413 in | 0.268 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7075 | 0.504 in | 0.536 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7001 | -2.965 in | 0.27 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3616 | -2.012 in | 0.27 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0697 | -0.138 in | 0.27 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6098 | -1.614 in | 0.27 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6615 | 0.953 in | 0.54 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 7.2845 | 0.87 in | 0.295 | True | observed / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 9.5216 | 2.732 in | 0.295 | True | observed / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.2351 | 0.925 in | 0.295 | True | observed / observed |
| `opening.top[door]` | scored | 4.074 | 4.0679 | -0.24 in | 0.295 | True | observed / observed |
| `opening.width[door]` | scored | 2.1898 | 2.2371 | 1.862 in | 0.59 | True | observed / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.526 | -1.543 in | 0.409 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5045 | -2.126 in | 0.538 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 4.9229 | 2.882 in | 0.565 | True | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.347 | 1.496 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 7.509 | 283.228 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | scored | 0.749 | 0.313 | -17.165 in | 0.05 | False | – / – |
| `facing.depth[w3@6.93]` | scored | 0.749 | 0.313 | -17.165 in | 0.05 | False | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | scored | 0.708 | 0.315 | -15.472 in | 0.05 | False | – / – |
| `facing.depth[w3@10.44]` | scored | 0.708 | 0.315 | -15.472 in | 0.05 | False | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.25 | -34.882 in | 0.05 | False | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 48%/92%/100% | 73%/99%/100% | 0.7483 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.6753 | 0.0 |
| wall_face | 58856 | 43%/86%/97% | 66%/95%/97% | 0.6772 | 0.902 | 0.006 | grazing, 0.8953, 0.0664 | 0.5995 | 0.0 |
| ground_strip | 206971 | 15%/45%/67% | 11%/34%/64% | 0.1072 | 0.0 | 0.1072 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 8%/23%/40% | 11%/29%/69% | 0.6746 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7388 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.039, in own unknown voxels 0.6763, flagged generated 0.0.
