# Geometry score: eth3d-facade/A2-pi3_518_images-posthoc-lidar_modern.draw0 vs eth3d-facade/gt-laser

Producer `A2-pi3_518_images-posthoc-lidar_modern.draw0`. Status counts: {'scored': 6, 'missing': 44, 'extent_limited': 1, 'phantom': 0, 'scale_reference': 0}.

**Key distances (6 scored):** median 4.02 in, p90 20.5 in, max 22.61 in; ≤2 in 33%, ≤4 in 50%, ≤6 in 67%; within the recon's own bound 83%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama None. Alignment: {'metric_declared': True, 'similarity_scale': 0.994731, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': 0.53, 'camera_rms_m': 0.3033, 'cameras': 16}.

**Anchor:** ICP translation 0.2925 m [0.0322, -0.0071, 0.2907], yaw -25.495°, tilt 0.579°.

**On truly observed elements:** 6 KDs, median 4.02 in, p90 20.5 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5169 | -0.28 in | 0.222 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 2.1664 | -538.724 in | 0.438 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -3.052 | -22.606 in | 0.383 | False | partial / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8903 | -4.22 in | 0.383 | True | partial / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0223 | 0.421 in | 0.383 | True | partial / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6728 | 3.827 in | 0.383 | True | partial / observed |
| `opening.width[win4]` | scored | 1.6947 | 2.1617 | 18.386 in | 0.766 | True | partial / observed |
| `opening.edge_s[win5:left]` | missing | 0.7754 |  |   |  |  | – / observed |
| `opening.edge_s[win5:right]` | missing | 2.4127 |  |   |  |  | – / observed |
| `opening.bottom[win5]` | missing | 1.0732 |  |   |  |  | – / observed |
| `opening.top[win5]` | missing | 3.6508 |  |   |  |  | – / observed |
| `opening.width[win5]` | missing | 1.6373 |  |   |  |  | – / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 5%/10%/21% | 73%/99%/100% | 0.3032 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3064 | 0.0 |
| wall_face | 58856 | 5%/10%/20% | 66%/94%/97% | 0.3195 | 0.902 | 0.0239 | grazing, 0.8953, 0.0664 | 0.3087 | 0.0 |
| ground_strip | 206971 | 9%/25%/37% | 12%/35%/65% | 0.0546 | 0.0 | 0.0546 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/1%/20% | 15%/31%/84% | 0.5258 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6263 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2047, in own unknown voxels 0.8024, flagged generated 0.0.
