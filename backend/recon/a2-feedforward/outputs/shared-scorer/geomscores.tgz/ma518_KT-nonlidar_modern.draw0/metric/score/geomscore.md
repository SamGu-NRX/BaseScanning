# Geometry score: eth3d-facade/A2-ma518_KT-nonlidar_modern.draw0-metric vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-nonlidar_modern.draw0-metric`. Status counts: {'scored': 24, 'missing': 26, 'extent_limited': 1, 'phantom': 16, 'scale_reference': 0}.

**Key distances (24 scored):** median 16.49 in, p90 37.25 in, max 40.84 in; ≤2 in 0%, ≤4 in 8%, ≤6 in 8%; within the recon's own bound 79%.

**Scale:** KD ratio median 0.95151 (n=4, error -4.849 %), landmark Umeyama 0.92244. Alignment: {'metric_declared': True, 'similarity_scale': 1.065735, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -6.168, 'camera_rms_m': 0.7561, 'cameras': 16}.

**Anchor:** ICP translation 1.8388 m [-0.2238, 0.0568, 1.8243], yaw -3.805°, tilt 0.606°.

**On truly observed elements:** 21 KDs, median 18.05 in, p90 37.29 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.2876 | -9.307 in | 0.207 | False | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 23.0858 | 284.874 in | 1.024 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.0545 | 34.0 in | 0.576 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -6.8696 | 18.051 in | 0.576 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.7196 | -6.138 in | 0.576 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 2.4821 | -37.287 in | 0.576 | False | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.1849 | -15.949 in | 1.152 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.4705 | 7.677 in | 0.534 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.3163 | -10.76 in | 0.534 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.7344 | -8.803 in | 0.534 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.4908 | -40.843 in | 0.534 | False | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.1542 | -18.437 in | 1.068 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.6985 | 30.681 in | 1.881 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.5418 | 9.5 in | 1.881 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9522 | -2.339 in | 1.881 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.632 | -37.15 in | 1.881 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.1567 | -21.181 in | 3.762 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.5842 | -7.528 in | 2.112 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.6378 | -30.508 in | 2.112 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0079 | -2.571 in | 2.112 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.6455 | -39.579 in | 2.112 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.0536 | -22.98 in | 4.224 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.3991 | -10.374 in | 1.11 | True | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.126 | -17.028 in | 3.993 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.883 | -9.961 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -10.2729 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 92.72 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 11.3495 |   |  |  | – / – |
| `opening.edge_s[rc:win3:left]` | phantom |  | -3.5787 |   |  |  | – / – |
| `opening.edge_s[rc:win3:right]` | phantom |  | -2.4304 |   |  |  | – / – |
| `opening.bottom[rc:win3]` | phantom |  | 0.8675 |   |  |  | – / – |
| `opening.top[rc:win3]` | phantom |  | 2.5839 |   |  |  | – / – |
| `opening.width[rc:win3]` | phantom |  | 1.1483 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 2.9516 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 4.7687 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1923 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.4963 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.8171 |   |  |  | – / – |
| `opening.gap[win3~rc:win3]` | phantom |  | 0.7376 |   |  |  | – / – |
| `opening.gap[rc:win3~win4]` | phantom |  | 0.7319 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.3138 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 1%/7%/29% | 46%/89%/100% | 0.2368 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.497 | 0.0 |
| wall_face | 58856 | 1%/6%/27% | 39%/78%/90% | 0.2734 | 0.902 | 0.0251 | grazing, 0.8953, 0.0664 | 0.4697 | 0.0 |
| ground_strip | 206971 | 5%/25%/52% | 9%/32%/66% | 0.0844 | 0.0 | 0.0844 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/1%/3% | 3%/16%/36% | 0.4993 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7116 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.4966, in own unknown voxels 0.9235, flagged generated 0.0.
