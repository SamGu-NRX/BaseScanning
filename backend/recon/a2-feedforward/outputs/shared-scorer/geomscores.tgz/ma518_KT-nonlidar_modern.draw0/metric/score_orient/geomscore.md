# Geometry score: eth3d-facade/A2-ma518_KT-nonlidar_modern.draw0-metric-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-nonlidar_modern.draw0-metric-orient`. Status counts: {'scored': 14, 'missing': 36, 'extent_limited': 1, 'phantom': 12, 'scale_reference': 0}.

**Key distances (14 scored):** median 15.06 in, p90 33.93 in, max 36.58 in; ≤2 in 7%, ≤4 in 21%, ≤6 in 29%; within the recon's own bound 86%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama 0.74285. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 1.4834 m [-0.127, 0.0493, 1.4772], yaw -8.493°, tilt 0.94°.

**On truly observed elements:** 11 KDs, median 16.18 in, p90 33.08 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.2932 | -9.087 in | 0.216 | False | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.6876 | -6.394 in | 1.018 | True | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.9197 | 21.972 in | 1.96 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.636 | 5.791 in | 1.96 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9287 | -3.264 in | 1.96 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.7355 | -33.075 in | 1.96 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.2837 | -16.181 in | 3.92 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.5683 | -8.154 in | 2.1 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.6891 | -28.488 in | 2.1 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 0.9994 | -2.906 in | 2.1 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.7216 | -36.583 in | 2.1 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.1208 | -20.335 in | 4.2 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.2043 | -13.945 in | 4.06 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.307 | -0.079 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.265 | -34.291 in | 0.05 | False | – / – |
| `opening.edge_s[rc:win3:left]` | phantom |  | -3.4124 |   |  |  | – / – |
| `opening.edge_s[rc:win3:right]` | phantom |  | -2.1364 |   |  |  | – / – |
| `opening.bottom[rc:win3]` | phantom |  | 0.8265 |   |  |  | – / – |
| `opening.top[rc:win3]` | phantom |  | 2.6673 |   |  |  | – / – |
| `opening.width[rc:win3]` | phantom |  | 1.276 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.0537 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 4.8809 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1803 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.5583 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.8272 |   |  |  | – / – |
| `opening.gap[rc:win3~win4]` | phantom |  | 0.2167 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.3646 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 6%/25%/65% | 44%/88%/100% | 0.1112 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.2698 | 0.0 |
| wall_face | 58856 | 5%/21%/57% | 39%/79%/90% | 0.1675 | 0.902 | 0.0236 | grazing, 0.8953, 0.0664 | 0.2779 | 0.0 |
| ground_strip | 206971 | 4%/13%/36% | 9%/31%/66% | 0.0829 | 0.0 | 0.0829 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/0%/5% | 2%/14%/36% | 0.4392 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6435 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.3514, in own unknown voxels 0.9321, flagged generated 0.0.
