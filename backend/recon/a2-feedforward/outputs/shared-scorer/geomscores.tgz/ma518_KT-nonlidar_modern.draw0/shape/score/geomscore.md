# Geometry score: eth3d-facade/A2-ma518_KT-nonlidar_modern.draw0-shape vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-nonlidar_modern.draw0-shape`. Status counts: {'scored': 25, 'missing': 25, 'extent_limited': 1, 'phantom': 16, 'scale_reference': 0}.

**Key distances (25 scored):** median 13.02 in, p90 29.97 in, max 33.64 in; ≤2 in 12%, ≤4 in 16%, ≤6 in 20%; within the recon's own bound 72%.

**Scale:** KD ratio median 1.08604 (n=4, error 8.604 %), landmark Umeyama 1.05112. Alignment: {'metric_declared': False, 'similarity_scale': 1.065735, 'method': 'similarity (unscaled cloud): camera centres -> GT cameras; scale error not meaningful', 'camera_rms_m': 0.3432, 'cameras': 16}.

**Anchor:** ICP translation 1.7112 m [-0.2143, 0.0522, 1.6969], yaw -6.278°, tilt 0.697°.

**On truly observed elements:** 21 KDs, median 15.33 in, p90 31.01 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.3709 | -6.028 in | 0.203 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 22.8996 | 277.543 in | 0.24 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.2487 | -13.016 in | 0.265 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.8435 | -20.291 in | 0.265 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.7056 | -6.689 in | 0.265 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 2.7075 | -28.413 in | 0.265 | False | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.4052 | -7.276 in | 0.53 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -6.2419 | -22.693 in | 0.323 | False | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.8974 | -33.638 in | 0.323 | False | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.7355 | -8.76 in | 0.323 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.714 | -32.055 in | 0.323 | False | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.3445 | -10.945 in | 0.646 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.9254 | 21.748 in | 1.971 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.6201 | 6.417 in | 1.971 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9946 | -0.669 in | 1.971 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.8595 | -28.193 in | 1.971 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.3053 | -15.331 in | 3.942 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6245 | -5.941 in | 2.168 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.7866 | -24.65 in | 2.168 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0672 | -0.236 in | 2.168 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.8632 | -31.008 in | 2.168 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.1621 | -18.709 in | 4.336 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6016 | -2.402 in | 0.588 | True | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.2446 | -12.358 in | 4.139 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.318 | 0.354 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.454 | -26.85 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -10.8491 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 97.42 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 13.338 |   |  |  | – / – |
| `opening.edge_s[rc:win3:left]` | phantom |  | -4.0783 |   |  |  | – / – |
| `opening.edge_s[rc:win3:right]` | phantom |  | -2.7562 |   |  |  | – / – |
| `opening.bottom[rc:win3]` | phantom |  | 0.8913 |   |  |  | – / – |
| `opening.top[rc:win3]` | phantom |  | 2.8156 |   |  |  | – / – |
| `opening.width[rc:win3]` | phantom |  | 1.3221 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.2168 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 5.1604 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1997 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.768 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.9436 |   |  |  | – / – |
| `opening.gap[win3~rc:win3]` | phantom |  | 0.8191 |   |  |  | – / – |
| `opening.gap[rc:win3~win4]` | phantom |  | 0.8308 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.4302 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 2%/12%/47% | 42%/90%/100% | 0.1623 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4673 | 0.0 |
| wall_face | 58856 | 2%/11%/42% | 37%/79%/90% | 0.2056 | 0.902 | 0.0189 | grazing, 0.8953, 0.0664 | 0.4446 | 0.0 |
| ground_strip | 206971 | 5%/21%/42% | 9%/30%/61% | 0.0823 | 0.0 | 0.0823 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/2%/5% | 2%/14%/39% | 0.4425 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6832 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.4237, in own unknown voxels 0.9305, flagged generated 0.0.
