# Geometry score: eth3d-facade/A2-ma518_KT-nonlidar_modern.draw0-shape-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_KT-nonlidar_modern.draw0-shape-orient`. Status counts: {'scored': 20, 'missing': 30, 'extent_limited': 1, 'phantom': 24, 'scale_reference': 0}.

**Key distances (20 scored):** median 15.99 in, p90 36.91 in, max 56.48 in; ≤2 in 15%, ≤4 in 20%, ≤6 in 25%; within the recon's own bound 95%.

**Scale:** KD ratio median 0.72694 (n=2, error -27.306 %), landmark Umeyama 0.73715. Alignment: {'metric_declared': False, 'method': 'given transform'}.

**Anchor:** ICP translation 1.6971 m [-0.1697, 0.0761, 1.6868], yaw -7.578°, tilt 1.01°.

**On truly observed elements:** 16 KDs, median 15.99 in, p90 38.98 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.3497 | -6.862 in | 0.224 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 14.6391 | -47.673 in | 0.278 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -4.2308 | 56.484 in | 2.237 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -2.8589 | 46.618 in | 2.237 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.8676 | -3.559 in | 2.237 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.8367 | -27.224 in | 2.237 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.3719 | -9.866 in | 4.474 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.0023 | 18.72 in | 2.01 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.6619 | 4.772 in | 2.01 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9686 | -1.693 in | 2.01 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.8672 | -27.89 in | 2.01 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.3404 | -13.949 in | 4.02 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6044 | -6.732 in | 2.183 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.7838 | -24.76 in | 2.183 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0375 | -1.406 in | 2.183 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.8548 | -31.339 in | 2.183 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.1794 | -18.028 in | 4.366 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 0.8566 | -27.898 in | 4.247 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.2663 | -11.504 in | 4.193 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.311 | 0.079 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.226 | -35.827 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -9.483 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -111.47 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -6.7742 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 124.53 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 6.0415 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 2.7088 |   |  |  | – / – |
| `opening.edge_s[rc:win1:left]` | phantom |  | -10.8327 |   |  |  | – / – |
| `opening.edge_s[rc:win1:right]` | phantom |  | -9.7467 |   |  |  | – / – |
| `opening.bottom[rc:win1]` | phantom |  | 0.8704 |   |  |  | – / – |
| `opening.top[rc:win1]` | phantom |  | 2.4304 |   |  |  | – / – |
| `opening.width[rc:win1]` | phantom |  | 1.086 |   |  |  | – / – |
| `opening.edge_s[rc:win2:left]` | phantom |  | -8.7897 |   |  |  | – / – |
| `opening.edge_s[rc:win2:right]` | phantom |  | -8.791 |   |  |  | – / – |
| `opening.bottom[rc:win2]` | phantom |  | 0.8484 |   |  |  | – / – |
| `opening.top[rc:win2]` | phantom |  | 2.4716 |   |  |  | – / – |
| `opening.width[rc:win2]` | phantom |  | -0.0013 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.2263 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 5.169 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1624 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.7452 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.9427 |   |  |  | – / – |
| `opening.gap[rc:win1~rc:win2]` | phantom |  | 0.957 |   |  |  | – / – |
| `opening.gap[rc:win2~win3]` | phantom |  | 4.5602 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.4425 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 2%/15%/51% | 41%/88%/100% | 0.1596 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3791 | 0.0 |
| wall_face | 58856 | 2%/13%/45% | 35%/77%/91% | 0.2023 | 0.902 | 0.0188 | grazing, 0.8953, 0.0664 | 0.3701 | 0.0 |
| ground_strip | 206971 | 4%/10%/32% | 9%/30%/62% | 0.0871 | 0.0 | 0.0871 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/2%/5% | 2%/13%/39% | 0.4458 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6766 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.4073, in own unknown voxels 0.93, flagged generated 0.0.
