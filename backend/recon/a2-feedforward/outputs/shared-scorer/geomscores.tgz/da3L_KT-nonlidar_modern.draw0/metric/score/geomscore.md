# Geometry score: eth3d-facade/A2-da3L_KT-nonlidar_modern.draw0-metric vs eth3d-facade/gt-laser

Producer `A2-da3L_KT-nonlidar_modern.draw0-metric`. Status counts: {'scored': 18, 'missing': 32, 'extent_limited': 1, 'phantom': 0, 'scale_reference': 0}.

**Key distances (18 scored):** median 2.87 in, p90 54.55 in, max 74.53 in; ≤2 in 33%, ≤4 in 67%, ≤6 in 67%; within the recon's own bound 89%.

**Scale:** KD ratio median 0.76736 (n=4, error -23.264 %), landmark Umeyama 0.75527. Alignment: {'metric_declared': True, 'similarity_scale': 1.037497, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.614, 'camera_rms_m': 0.5297, 'cameras': 16}.

**Anchor:** ICP translation 0.5552 m [-0.5051, -0.0158, 0.23], yaw -0.184°, tilt 0.451°.

**On truly observed elements:** 16 KDs, median 2.72 in, p90 58.01 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.57 | 1.811 in | 0.192 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 7.0772 | -345.386 in | 0.67 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -7.0249 | 74.535 in | 0.446 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -5.4742 | 72.988 in | 0.446 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9498 | 2.925 in | 0.446 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4318 | 0.102 in | 0.446 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5507 | -1.547 in | 0.892 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -4.5867 | 42.472 in | 2.311 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -2.9498 | 43.039 in | 2.311 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0245 | 2.618 in | 2.311 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.5758 | 1.874 in | 2.311 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6369 | 0.567 in | 4.622 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5696 | -3.614 in | 0.218 | True | partial / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8209 | -1.488 in | 0.218 | True | partial / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0833 | 2.823 in | 0.218 | True | partial / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6665 | 3.579 in | 0.218 | True | partial / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7487 | 2.126 in | 0.436 | True | partial / observed |
| `opening.edge_s[win5:left]` | missing | 0.7754 |  |   |  |  | – / observed |
| `opening.edge_s[win5:right]` | missing | 2.4127 |  |   |  |  | – / observed |
| `opening.bottom[win5]` | missing | 1.0732 |  |   |  |  | – / observed |
| `opening.top[win5]` | missing | 3.6508 |  |   |  |  | – / observed |
| `opening.width[win5]` | missing | 1.6373 |  |   |  |  | – / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 0.8875 | -30.516 in | 2.757 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 0.3802 | -46.654 in | 2.529 | True | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 19%/57%/98% | 30%/70%/94% | 0.4039 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3441 | 0.0 |
| wall_face | 58856 | 17%/52%/92% | 26%/61%/83% | 0.3758 | 0.902 | 0.0017 | grazing, 0.8953, 0.0664 | 0.3237 | 0.0 |
| ground_strip | 206971 | 8%/34%/61% | 16%/36%/50% | 0.0511 | 0.0 | 0.0511 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 3%/15%/39% | 11%/30%/65% | 0.4854 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6614 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.1154, in own unknown voxels 0.8781, flagged generated 0.0.
