# Geometry score: eth3d-facade/A2-da3L_KT-nonlidar_modern.draw0-metric-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_KT-nonlidar_modern.draw0-metric-orient`. Status counts: {'scored': 32, 'missing': 18, 'extent_limited': 1, 'phantom': 9, 'scale_reference': 0}.

**Key distances (32 scored):** median 2.91 in, p90 52.47 in, max 215.67 in; ≤2 in 44%, ≤4 in 53%, ≤6 in 56%; within the recon's own bound 75%.

**Scale:** KD ratio median 0.91019 (n=7, error -8.981 %), landmark Umeyama 0.91521. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.5853 m [-0.5194, -0.0128, 0.2694], yaw 0.763°, tilt 0.097°.

**On truly observed elements:** 26 KDs, median 2.17 in, p90 51.7 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5413 | 0.681 in | 0.146 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 13.9599 | -74.413 in | 0.674 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -7.5806 | 52.657 in | 0.416 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -6.039 | 50.752 in | 0.416 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9251 | 1.953 in | 0.416 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4146 | -0.575 in | 0.416 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5416 | -1.906 in | 0.832 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.1567 | 20.031 in | 2.274 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.521 | 20.551 in | 2.274 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0013 | 1.705 in | 2.274 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.568 | 1.567 in | 2.274 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6357 | 0.52 in | 4.548 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5649 | -3.429 in | 1.874 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8307 | -1.874 in | 1.874 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0516 | 1.575 in | 1.874 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6365 | 2.398 in | 1.874 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7342 | 1.555 in | 3.748 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.2155 | -22.043 in | 0.152 | False | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.8752 | -21.161 in | 0.152 | False | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.1064 | 1.307 in | 0.152 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6969 | 1.815 in | 0.152 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6597 | 0.882 in | 0.304 | True | partial / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 11.7869 | 178.13 in | 2.692 | False | partial / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 14.9302 | 215.669 in | 2.692 | False | partial / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.151 | -2.386 in | 2.692 | True | partial / observed |
| `opening.top[door]` | scored | 4.074 | 4.2095 | 5.335 in | 2.692 | True | partial / observed |
| `opening.width[door]` | scored | 2.1898 | 3.1433 | 37.539 in | 5.384 | True | partial / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 0.8823 | -30.72 in | 2.69 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 0.9561 | -23.98 in | 4.148 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.0462 | -20.169 in | 2.026 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 9.9117 | 199.291 in | 2.844 | False | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.318 | 0.354 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.266 | -34.252 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | 4.9095 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 120.82 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 10.0739 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -147.5 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 19.2524 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 31.12 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 5.1644 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 9.1784 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 1.5294 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 22%/58%/92% | 32%/87%/96% | 0.3701 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3177 | 0.0 |
| wall_face | 58856 | 19%/51%/82% | 28%/77%/86% | 0.3393 | 0.902 | 0.005 | grazing, 0.8953, 0.0664 | 0.3061 | 0.0 |
| ground_strip | 206971 | 14%/39%/54% | 16%/38%/50% | 0.1057 | 0.0 | 0.1057 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 2%/9%/36% | 1%/4%/31% | 0.3763 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.5463 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.11, in own unknown voxels 0.7961, flagged generated 0.0.
