# Geometry score: eth3d-facade/A2-da3L_KT-nonlidar_modern.draw0-shape vs eth3d-facade/gt-laser

Producer `A2-da3L_KT-nonlidar_modern.draw0-shape`. Status counts: {'scored': 20, 'missing': 30, 'extent_limited': 1, 'phantom': 6, 'scale_reference': 0}.

**Key distances (20 scored):** median 8.37 in, p90 130.71 in, max 158.31 in; ≤2 in 5%, ≤4 in 30%, ≤6 in 35%; within the recon's own bound 60%.

**Scale:** KD ratio median 1.45033 (n=3, error 45.033 %), landmark Umeyama 1.02632. Alignment: {'metric_declared': False, 'similarity_scale': 1.037497, 'method': 'similarity (unscaled cloud): camera centres -> GT cameras; scale error not meaningful', 'camera_rms_m': 0.3532, 'cameras': 16}.

**Anchor:** ICP translation 0.5546 m [-0.4371, -0.0496, 0.3378], yaw -1.215°, tilt 0.123°.

**On truly observed elements:** 16 KDs, median 7.58 in, p90 79.16 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.6119 | 3.461 in | 0.209 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 7.8859 | -313.547 in | 0.266 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.6905 | -8.374 in | 1.957 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8725 | -3.52 in | 1.957 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.1084 | 3.811 in | 1.957 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.7882 | 8.37 in | 1.957 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.818 | 4.854 in | 3.914 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.212 | -22.181 in | 0.163 | False | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.9183 | -19.465 in | 0.163 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.1625 | 3.516 in | 0.163 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.8235 | 6.799 in | 0.163 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.7063 | 2.717 in | 0.326 | True | observed / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 10.5329 | 128.76 in | 2.099 | False | partial / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 13.4733 | 158.311 in | 2.099 | False | partial / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.161 | -1.992 in | 2.099 | True | partial / observed |
| `opening.top[door]` | scored | 4.074 | 4.349 | 10.827 in | 2.099 | True | partial / observed |
| `opening.width[door]` | scored | 2.1898 | 2.9404 | 29.551 in | 4.198 | True | partial / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.0845 | -18.661 in | 2.12 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 8.6146 | 148.224 in | 2.262 | False | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.5 | 7.52 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.22 | -36.063 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | 4.5721 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 117.7 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 8.945 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -140.9 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 4.3729 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 9.6968 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 21%/53%/78% | 40%/91%/98% | 0.3391 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3045 | 0.0 |
| wall_face | 58856 | 18%/48%/72% | 35%/79%/88% | 0.3146 | 0.902 | 0.0049 | grazing, 0.8953, 0.0664 | 0.2845 | 0.0 |
| ground_strip | 206971 | 8%/33%/57% | 15%/35%/49% | 0.0561 | 0.0 | 0.0561 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 3%/16%/51% | 0%/4%/26% | 0.3889 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.5648 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.125, in own unknown voxels 0.8031, flagged generated 0.0.
