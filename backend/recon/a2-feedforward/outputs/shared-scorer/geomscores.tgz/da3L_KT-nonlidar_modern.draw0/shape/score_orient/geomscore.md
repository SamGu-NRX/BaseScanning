# Geometry score: eth3d-facade/A2-da3L_KT-nonlidar_modern.draw0-shape-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_KT-nonlidar_modern.draw0-shape-orient`. Status counts: {'scored': 14, 'missing': 36, 'extent_limited': 1, 'phantom': 6, 'scale_reference': 0}.

**Key distances (14 scored):** median 12.58 in, p90 41.77 in, max 46.7 in; ≤2 in 7%, ≤4 in 29%, ≤6 in 36%; within the recon's own bound 79%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama 0.89684. Alignment: {'metric_declared': False, 'method': 'given transform'}.

**Anchor:** ICP translation 0.7742 m [0.0693, -0.0323, 0.7705], yaw -21.844°, tilt 0.065°.

**On truly observed elements:** 11 KDs, median 6.39 in, p90 42.24 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5763 | 2.059 in | 0.204 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 10.786 | -199.37 in | 0.246 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -3.1169 | -25.161 in | 0.273 | False | partial / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.9981 | -8.465 in | 0.273 | True | partial / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0691 | 2.264 in | 0.273 | True | partial / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.738 | 6.394 in | 0.273 | True | partial / observed |
| `opening.width[win4]` | scored | 1.6947 | 2.1188 | 16.697 in | 0.546 | True | partial / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | -0.4109 | -46.705 in | 2.163 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.3397 | -42.244 in | 2.163 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.1731 | 3.933 in | 2.163 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6806 | 1.173 in | 2.163 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.7506 | 4.461 in | 4.326 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 0.5872 | -38.24 in | 2.436 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 1.342 | 40.669 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.488 | -25.512 in | 0.05 | False | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.3288 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 5.7663 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0482 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.5907 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.4375 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.9891 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 4%/10%/25% | 45%/96%/99% | 0.2709 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.2606 | 0.0 |
| wall_face | 58856 | 4%/10%/24% | 41%/88%/96% | 0.289 | 0.902 | 0.0134 | grazing, 0.8953, 0.0664 | 0.2701 | 0.0 |
| ground_strip | 206971 | 12%/26%/36% | 14%/34%/45% | 0.0698 | 0.0 | 0.0698 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/1%/20% | 20%/41%/96% | 0.4061 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.459 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2341, in own unknown voxels 0.8054, flagged generated 0.0.
