# Geometry score: eth3d-facade/A2-da3L_images-shape vs eth3d-facade/gt-laser

Producer `A2-da3L_images-shape`. Status counts: {'scored': 34, 'missing': 16, 'extent_limited': 1, 'phantom': 21, 'scale_reference': 0}.

**Key distances (33 scored):** median 2.26 in, p90 7.73 in, max 90.39 in; ≤2 in 48%, ≤4 in 61%, ≤6 in 79%; within the recon's own bound 94%.

**Scale:** KD ratio median 1.02017 (n=8, error 2.017 %), landmark Umeyama 1.01816. Alignment: {'metric_declared': False, 'similarity_scale': 16.882611, 'method': 'similarity (unscaled cloud): camera centres -> GT cameras; scale error not meaningful', 'camera_rms_m': 0.2492, 'cameras': 16}.

**Anchor:** ICP translation 0.3294 m [0.0004, -0.0273, 0.3283], yaw -2.26°, tilt 1.276°.

**On truly observed elements:** 26 KDs, median 2.37 in, p90 7.56 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5432 | 0.756 in | 0.226 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.8811 | -5.386 in | 0.308 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 86.5 | -4.61 deg | 17.1188 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.8848 | 1.37 in | 0.308 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.5715 | 1.138 in | 0.282 | True | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.5737 | -14.067 in | 0.352 | False | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.9587 | -11.807 in | 0.352 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0823 | 6.61 in | 0.352 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.5872 | 7.835 in | 0.352 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.615 | 2.26 in | 0.704 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.1034 | -7.295 in | 0.202 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.4752 | -5.791 in | 0.202 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 1.0044 | 5.075 in | 0.202 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.5821 | 6.02 in | 0.202 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.6282 | 1.504 in | 0.404 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.7803 | -4.52 in | 0.189 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.1228 | -3.142 in | 0.189 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0335 | 2.972 in | 0.189 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.6332 | 4.134 in | 0.189 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6575 | 1.378 in | 0.378 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5149 | -1.461 in | 0.233 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8041 | -0.827 in | 0.233 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0607 | 1.933 in | 0.233 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6387 | 2.484 in | 0.233 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7108 | 0.634 in | 0.466 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7822 | 0.268 in | 0.256 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.4183 | 0.22 in | 0.256 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.1036 | 1.197 in | 0.256 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6813 | 1.201 in | 0.256 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6361 | -0.047 in | 0.512 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.8553 | 4.512 in | 0.554 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6949 | 1.272 in | 0.391 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.6079 | 1.681 in | 0.422 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5863 | 1.094 in | 0.489 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 2.611 | 90.394 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -13.0037 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 93.07 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 6.4526 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -138.01 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | 9.9795 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 112.62 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | 12.7167 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | -102.63 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | 17.3209 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | 47.57 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 5.0025 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 3.527 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 2.7373 |   |  |  | – / – |
| `wall.length[rc:w6]` | phantom |  | 4.6042 |   |  |  | – / – |
| `wall.length[rc:w7]` | phantom |  | 3.5736 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 11.2047 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 11.8315 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.6809 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 0.6268 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 8.7864 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 11%/48%/92% | 33%/79%/100% | 0.3438 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.2979 | 0.0 |
| wall_face | 58856 | 11%/46%/85% | 31%/74%/97% | 0.3452 | 0.902 | 0.0072 | grazing, 0.8953, 0.0664 | 0.3014 | 0.0 |
| ground_strip | 206971 | 9%/29%/57% | 14%/31%/54% | 0.0811 | 0.0 | 0.0811 | unobserved, 0.0, 0.4654 | 0.0006 | 0.0006 |
| overhead | 1602 | 0%/3%/31% | 17%/32%/56% | 0.3743 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6296 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.1053, in own unknown voxels 0.7447, flagged generated 0.0.
