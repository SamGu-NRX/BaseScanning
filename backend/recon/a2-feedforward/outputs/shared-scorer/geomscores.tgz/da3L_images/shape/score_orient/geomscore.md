# Geometry score: eth3d-facade/A2-da3L_images-shape-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_images-shape-orient`. Status counts: {'scored': 40, 'missing': 10, 'extent_limited': 1, 'phantom': 6, 'scale_reference': 0}.

**Key distances (39 scored):** median 3.05 in, p90 15.45 in, max 43.31 in; ≤2 in 44%, ≤4 in 59%, ≤6 in 72%; within the recon's own bound 92%.

**Scale:** KD ratio median 1.015 (n=11, error 1.5 %), landmark Umeyama 1.01369. Alignment: {'metric_declared': False, 'method': 'given transform'}.

**Anchor:** ICP translation 0.262 m [-0.0476, -0.0268, 0.2563], yaw -1.369°, tilt 0.048°.

**On truly observed elements:** 31 KDs, median 3.05 in, p90 13.11 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5385 | 0.571 in | 0.197 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.982 | -1.413 in | 0.246 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 91.04 | -0.07 deg | 13.8203 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 16.0224 | 6.787 in | 0.246 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 3.0674 | -18.707 in | 0.214 | False | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.4432 | -8.929 in | 0.324 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.8651 | -8.122 in | 0.324 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0734 | 6.26 in | 0.324 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.5549 | 6.563 in | 0.324 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5781 | 0.807 in | 0.648 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.0401 | -4.803 in | 0.17 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.438 | -4.327 in | 0.17 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9973 | 4.795 in | 0.17 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.5604 | 5.165 in | 0.17 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.6021 | 0.476 in | 0.34 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.7624 | -3.815 in | 0.156 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.1204 | -3.047 in | 0.156 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0271 | 2.72 in | 0.156 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.6219 | 3.689 in | 0.156 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.642 | 0.768 in | 0.312 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5226 | -1.764 in | 0.2 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8143 | -1.228 in | 0.2 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0547 | 1.697 in | 0.2 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6388 | 2.488 in | 0.2 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7083 | 0.535 in | 0.4 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7724 | -0.118 in | 0.243 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.432 | 0.76 in | 0.243 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0982 | 0.984 in | 0.243 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6933 | 1.673 in | 0.243 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6596 | 0.878 in | 0.486 | True | partial / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 6.91 | -13.874 in | 0.554 | True | unobserved / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 10.1653 | 28.075 in | 0.554 | False | unobserved / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.0619 | -5.894 in | 0.554 | True | unobserved / observed |
| `opening.top[door]` | scored | 4.074 | 4.4069 | 13.106 in | 0.554 | True | unobserved / observed |
| `opening.width[door]` | scored | 2.1898 | 3.2553 | 41.949 in | 1.108 | True | unobserved / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.825 | 3.319 in | 0.494 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6756 | 0.512 in | 0.326 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5978 | 1.283 in | 0.356 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5867 | 1.11 in | 0.443 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 4.478 | -14.634 in | 0.797 | True | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 1.415 | 43.307 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -13.0404 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 92.85 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 6.0493 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -115.16 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 4.9902 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 6.6368 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 25%/77%/98% | 31%/76%/100% | 0.412 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.323 | 0.0 |
| wall_face | 58856 | 23%/71%/92% | 29%/71%/97% | 0.4019 | 0.902 | 0.0061 | grazing, 0.8953, 0.0664 | 0.3183 | 0.0 |
| ground_strip | 206971 | 15%/31%/54% | 13%/31%/52% | 0.0993 | 0.0 | 0.0993 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 2%/11%/38% | 18%/32%/57% | 0.4041 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6534 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0828, in own unknown voxels 0.7327, flagged generated 0.0.
