# Geometry score: eth3d-facade/A2-da3L_images-posthoc-lidar_modern.draw0 vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-lidar_modern.draw0`. Status counts: {'scored': 32, 'missing': 18, 'extent_limited': 1, 'phantom': 33, 'scale_reference': 0}.

**Key distances (32 scored):** median 2.02 in, p90 6.67 in, max 19.09 in; ≤2 in 47%, ≤4 in 75%, ≤6 in 84%; within the recon's own bound 94%.

**Scale:** KD ratio median 1.00455 (n=6, error 0.455 %), landmark Umeyama 1.01245. Alignment: {'metric_declared': True, 'similarity_scale': 0.994407, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': 0.562, 'camera_rms_m': 0.2566, 'cameras': 16}.

**Anchor:** ICP translation 0.8728 m [0.0144, -0.0223, 0.8724], yaw -3.48°, tilt 1.264°.

**On truly observed elements:** 26 KDs, median 2.02 in, p90 6.55 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5522 | 1.11 in | 0.204 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 18.2716 | 95.339 in | 1.06 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.4611 | -9.634 in | 0.718 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.8389 | -7.091 in | 0.718 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0845 | 6.697 in | 0.718 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.5506 | 6.394 in | 0.718 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.6222 | 2.543 in | 1.436 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.9691 | -2.008 in | 0.443 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.3529 | -0.976 in | 0.443 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 1.0156 | 5.516 in | 0.443 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.5355 | 4.185 in | 0.443 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.6162 | 1.031 in | 0.886 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.6471 | 0.724 in | 0.357 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.0221 | 0.823 in | 0.357 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.053 | 3.74 in | 0.357 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.5733 | 1.776 in | 0.357 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.625 | 0.098 in | 0.714 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4385 | 1.547 in | 0.324 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7815 | 0.063 in | 0.324 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0859 | 2.925 in | 0.324 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.5682 | -0.291 in | 0.324 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.657 | -1.484 in | 0.648 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7642 | -0.441 in | 0.453 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3479 | -2.551 in | 0.453 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.133 | 2.354 in | 0.453 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.5994 | -2.024 in | 0.453 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5837 | -2.11 in | 0.906 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.8698 | 5.083 in | 1.161 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.7058 | 1.701 in | 0.8 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5836 | 0.724 in | 0.681 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5457 | -0.504 in | 0.777 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.373 | 2.52 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.651 | -19.094 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -13.3734 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 96.88 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 4.8982 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 115.07 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 8.592 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 142.85 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | 11.3375 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 118.55 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | 15.0762 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | 38.71 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | 15.3609 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | 139.59 |   |  |  | – / – |
| `corner.s[rc:c7]` | phantom |  | 18.8844 |   |  |  | – / – |
| `corner.turn[rc:c7]` | phantom |  | 80.47 |   |  |  | – / – |
| `corner.s[rc:c8]` | phantom |  | 20.5286 |   |  |  | – / – |
| `corner.turn[rc:c8]` | phantom |  | -96.81 |   |  |  | – / – |
| `corner.s[rc:c9]` | phantom |  | 36.9569 |   |  |  | – / – |
| `corner.turn[rc:c9]` | phantom |  | -93.58 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 3.4031 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 3.6938 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 2.7454 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 3.7386 |   |  |  | – / – |
| `wall.length[rc:w6]` | phantom |  | 0.2848 |   |  |  | – / – |
| `wall.length[rc:w7]` | phantom |  | 3.5235 |   |  |  | – / – |
| `wall.length[rc:w8]` | phantom |  | 1.6442 |   |  |  | – / – |
| `wall.length[rc:w9]` | phantom |  | 16.4282 |   |  |  | – / – |
| `wall.length[rc:w10]` | phantom |  | 4.792 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 12.8165 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 14.9921 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0894 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.3749 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.1756 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 10.4686 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 1%/9%/31% | 33%/83%/100% | 0.4228 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.6059 | 0.0 |
| wall_face | 58856 | 2%/11%/32% | 31%/78%/97% | 0.4179 | 0.902 | 0.0121 | grazing, 0.8953, 0.0664 | 0.5616 | 0.0 |
| ground_strip | 206971 | 9%/27%/55% | 14%/30%/52% | 0.0787 | 0.0 | 0.0787 | unobserved, 0.0, 0.4654 | 0.0007 | 0.0007 |
| overhead | 1602 | 0%/3%/16% | 17%/31%/59% | 0.4292 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7335 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.287, in own unknown voxels 0.7371, flagged generated 0.0.
