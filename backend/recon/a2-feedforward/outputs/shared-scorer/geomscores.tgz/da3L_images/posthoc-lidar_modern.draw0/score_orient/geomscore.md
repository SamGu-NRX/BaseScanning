# Geometry score: eth3d-facade/A2-da3L_images-posthoc-lidar_modern.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-lidar_modern.draw0-orient`. Status counts: {'scored': 35, 'missing': 15, 'extent_limited': 1, 'phantom': 12, 'scale_reference': 0}.

**Key distances (34 scored):** median 2.03 in, p90 9.77 in, max 38.35 in; ≤2 in 50%, ≤4 in 65%, ≤6 in 79%; within the recon's own bound 94%.

**Scale:** KD ratio median 1.01445 (n=8, error 1.445 %), landmark Umeyama 1.02664. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.486 m [-0.0427, -0.0277, 0.4833], yaw -2.54°, tilt 0.019°.

**On truly observed elements:** 26 KDs, median 2.03 in, p90 7.34 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5534 | 1.157 in | 0.19 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 3.2593 | 9.504 in | 0.628 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 97.41 | 6.3 deg | 45.6234 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 16.3665 | 20.335 in | 1.022 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 2.6891 | -33.603 in | 0.63 | False | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.5221 | -12.035 in | 0.701 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.9099 | -9.886 in | 0.701 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0936 | 7.055 in | 0.701 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.5819 | 7.626 in | 0.701 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.6122 | 2.15 in | 1.402 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.0508 | -5.224 in | 0.435 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.4308 | -4.043 in | 0.435 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 1.0184 | 5.626 in | 0.435 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.5736 | 5.685 in | 0.435 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.62 | 1.181 in | 0.87 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.7326 | -2.642 in | 0.332 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.0894 | -1.827 in | 0.332 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.05 | 3.622 in | 0.332 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.62 | 3.614 in | 0.332 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6432 | 0.815 in | 0.664 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4916 | -0.543 in | 0.29 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.801 | -0.705 in | 0.29 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0784 | 2.63 in | 0.29 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6223 | 1.839 in | 0.29 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6906 | -0.161 in | 0.58 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7702 | -0.205 in | 0.331 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3821 | -1.205 in | 0.331 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.1219 | 1.917 in | 0.331 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6614 | 0.417 in | 0.331 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6119 | -1.0 in | 0.662 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.8591 | 4.661 in | 1.136 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6982 | 1.402 in | 0.767 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5978 | 1.283 in | 0.622 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5712 | 0.5 in | 0.621 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.329 | 0.787 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 3.11 | 38.346 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -13.1072 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 93.16 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 5.9483 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -120.4 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 4.6147 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 8.6474 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 6.8387 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 9.9547 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0767 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.4104 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 3.116 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 4.4566 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 5%/20%/58% | 33%/82%/100% | 0.4458 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4937 | 0.0 |
| wall_face | 58856 | 6%/22%/56% | 31%/77%/97% | 0.4306 | 0.902 | 0.0077 | grazing, 0.8953, 0.0664 | 0.4669 | 0.0 |
| ground_strip | 206971 | 15%/31%/57% | 14%/31%/54% | 0.0923 | 0.0 | 0.0923 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/1%/24% | 18%/32%/60% | 0.4385 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7262 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.12, in own unknown voxels 0.7347, flagged generated 0.0.
