# Geometry score: eth3d-facade/A2-da3L_images-posthoc-exact-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-exact-orient`. Status counts: {'scored': 37, 'missing': 13, 'extent_limited': 1, 'phantom': 46, 'scale_reference': 0}.

**Key distances (36 scored):** median 4.4 in, p90 842.48 in, max 2076.27 in; ≤2 in 36%, ≤4 in 50%, ≤6 in 56%; within the recon's own bound 61%.

**Scale:** KD ratio median 2.55519 (n=8, error 155.519 %), landmark Umeyama 0.99099. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.3371 m [-0.049, -0.0276, 0.3324], yaw -0.903°, tilt 0.056°.

**On truly observed elements:** 31 KDs, median 3.46 in, p90 906.87 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.5393 | 0.602 in | 0.19 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 3.0186 | 0.028 in | 0.627 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 92.81 | 1.7 deg | 45.6794 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 16.2421 | 15.437 in | 1.024 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 2.9469 | -23.45 in | 0.59 | False | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -22.4463 | -402.752 in | 1.053 | False | grazing / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -23.8844 | -520.693 in | 1.053 | False | grazing / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0914 | 6.969 in | 1.053 | True | grazing / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.476 | 3.457 in | 1.053 | True | grazing / observed |
| `opening.width[win1]` | scored | 1.5576 | -1.4381 | -117.941 in | 2.106 | False | grazing / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -25.591 | -656.413 in | 0.983 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -27.0919 | -778.102 in | 0.983 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 1.0112 | 5.343 in | 0.983 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.5104 | 3.197 in | 0.983 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | -1.5009 | -121.689 in | 1.966 | False | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -28.6999 | -906.866 in | 1.07 | False | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -30.2823 | -1033.043 in | 1.07 | False | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0323 | 2.925 in | 1.07 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.6022 | 2.913 in | 1.07 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | -1.5824 | -126.177 in | 2.14 | False | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5105 | -1.287 in | 0.272 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8123 | -1.15 in | 0.272 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0569 | 1.783 in | 0.272 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.6304 | 2.157 in | 0.272 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6982 | 0.138 in | 0.544 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7694 | -0.236 in | 0.283 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.4156 | 0.114 in | 0.283 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0996 | 1.039 in | 0.283 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.6895 | 1.524 in | 0.283 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6462 | 0.35 in | 0.566 | True | partial / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | -45.4748 | -2076.268 in | 1.555 | False | observed / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | -43.125 | -2069.969 in | 1.555 | False | observed / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.1689 | -1.681 in | 1.555 | True | observed / observed |
| `opening.top[door]` | scored | 4.074 | 4.2209 | 5.783 in | 1.555 | True | observed / observed |
| `opening.width[door]` | scored | 2.1898 | 2.3498 | 6.299 in | 3.11 | True | observed / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5817 | 0.913 in | 0.555 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 1.348 | 40.906 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 2.914 | 102.323 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -74.9402 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 92.23 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -58.8303 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 91.37 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -55.0336 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -142.75 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -53.1546 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 67.09 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | -51.0161 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | -144.02 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | -48.827 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | -103.08 |   |  |  | – / – |
| `corner.s[rc:c7]` | phantom |  | -46.0041 |   |  |  | – / – |
| `corner.turn[rc:c7]` | phantom |  | -131.56 |   |  |  | – / – |
| `corner.s[rc:c8]` | phantom |  | -42.4148 |   |  |  | – / – |
| `corner.turn[rc:c8]` | phantom |  | -140.73 |   |  |  | – / – |
| `corner.s[rc:c9]` | phantom |  | -36.0654 |   |  |  | – / – |
| `corner.turn[rc:c9]` | phantom |  | -39.61 |   |  |  | – / – |
| `corner.s[rc:c10]` | phantom |  | -21.3355 |   |  |  | – / – |
| `corner.turn[rc:c10]` | phantom |  | -88.16 |   |  |  | – / – |
| `corner.s[rc:c11]` | phantom |  | -17.4024 |   |  |  | – / – |
| `corner.turn[rc:c11]` | phantom |  | 88.46 |   |  |  | – / – |
| `corner.s[rc:c12]` | phantom |  | -17.3437 |   |  |  | – / – |
| `corner.turn[rc:c12]` | phantom |  | 89.78 |   |  |  | – / – |
| `corner.s[rc:c13]` | phantom |  | -13.2235 |   |  |  | – / – |
| `corner.turn[rc:c13]` | phantom |  | 93.34 |   |  |  | – / – |
| `corner.s[rc:c15]` | phantom |  | 5.9655 |   |  |  | – / – |
| `corner.turn[rc:c15]` | phantom |  | -110.86 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 5.0863 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 16.1099 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 3.7967 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 1.8789 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 2.1386 |   |  |  | – / – |
| `wall.length[rc:w6]` | phantom |  | 2.1891 |   |  |  | – / – |
| `wall.length[rc:w7]` | phantom |  | 2.8228 |   |  |  | – / – |
| `wall.length[rc:w8]` | phantom |  | 3.5893 |   |  |  | – / – |
| `wall.length[rc:w9]` | phantom |  | 6.3495 |   |  |  | – / – |
| `wall.length[rc:w10]` | phantom |  | 14.7298 |   |  |  | – / – |
| `wall.length[rc:w11]` | phantom |  | 3.9331 |   |  |  | – / – |
| `wall.length[rc:w12]` | phantom |  | 0.0588 |   |  |  | – / – |
| `wall.length[rc:w13]` | phantom |  | 4.1202 |   |  |  | – / – |
| `wall.length[rc:w16]` | phantom |  | 9.6602 |   |  |  | – / – |
| `opening.gap[door~win3]` | phantom |  | 14.4251 |   |  |  | – / – |
| `opening.gap[win3~win2]` | phantom |  | 4.6913 |   |  |  | – / – |
| `opening.gap[win2~win1]` | phantom |  | 4.6456 |   |  |  | – / – |
| `opening.gap[win1~win4]` | phantom |  | 21.3739 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 3%/21%/92% | 32%/76%/100% | 0.4083 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3336 | 0.0 |
| wall_face | 58856 | 4%/23%/87% | 30%/71%/97% | 0.3978 | 0.902 | 0.0074 | grazing, 0.8953, 0.0664 | 0.3277 | 0.0 |
| ground_strip | 206971 | 15%/31%/54% | 13%/31%/53% | 0.0938 | 0.0 | 0.0938 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 2%/12%/38% | 14%/30%/58% | 0.4048 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6541 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0834, in own unknown voxels 0.7401, flagged generated 0.0.
