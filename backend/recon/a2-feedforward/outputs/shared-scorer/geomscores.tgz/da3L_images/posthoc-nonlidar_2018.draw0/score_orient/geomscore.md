# Geometry score: eth3d-facade/A2-da3L_images-posthoc-nonlidar_2018.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-nonlidar_2018.draw0-orient`. Status counts: {'scored': 41, 'missing': 9, 'extent_limited': 1, 'phantom': 9, 'scale_reference': 0}.

**Key distances (40 scored):** median 3.87 in, p90 24.62 in, max 45.02 in; ≤2 in 32%, ≤4 in 55%, ≤6 in 70%; within the recon's own bound 88%.

**Scale:** KD ratio median 0.96933 (n=11, error -3.067 %), landmark Umeyama 0.96631. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.4082 m [-0.0796, 0.0231, 0.3997], yaw -0.89°, tilt 0.369°.

**On truly observed elements:** 31 KDs, median 3.85 in, p90 11.55 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4877 | -1.429 in | 0.187 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.8459 | -6.772 in | 0.601 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 90.43 | -0.68 deg | 44.1865 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.2249 | -24.61 in | 0.972 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 2.4947 | -41.256 in | 0.532 | False | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -11.9231 | 11.547 in | 0.672 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.4039 | 10.035 in | 0.672 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0496 | 5.323 in | 0.672 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.4206 | 1.276 in | 0.672 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5192 | -1.512 in | 1.344 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.6446 | 10.768 in | 0.418 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.1093 | 8.614 in | 0.418 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9763 | 3.969 in | 0.418 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4185 | -0.421 in | 0.418 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5353 | -2.154 in | 0.836 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.4949 | 6.717 in | 0.319 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.9287 | 4.5 in | 0.319 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0045 | 1.831 in | 0.319 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.4692 | -2.323 in | 0.319 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5662 | -2.217 in | 0.638 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4021 | 2.98 in | 0.277 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7803 | 0.11 in | 0.277 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0298 | 0.717 in | 0.277 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.4779 | -3.846 in | 0.277 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6218 | -2.87 in | 0.554 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7295 | -1.807 in | 0.305 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.2859 | -4.992 in | 0.305 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.07 | -0.126 in | 0.305 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.5224 | -5.055 in | 0.305 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5564 | -3.185 in | 0.61 | True | partial / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 6.1188 | -45.024 in | 0.634 | False | unobserved / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 8.891 | -22.094 in | 0.634 | True | unobserved / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.0927 | -4.681 in | 0.634 | True | unobserved / observed |
| `opening.top[door]` | scored | 4.074 | 4.1895 | 4.547 in | 0.634 | True | unobserved / observed |
| `opening.width[door]` | scored | 2.1898 | 2.7722 | 22.929 in | 1.268 | True | unobserved / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.7593 | 0.732 in | 1.09 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6144 | -1.898 in | 0.737 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5266 | -1.52 in | 0.596 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5098 | -1.917 in | 0.582 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 3.8329 | -40.031 in | 0.939 | False | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.408 | 3.898 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 1.328 | 39.882 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -18.2387 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 51.39 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -12.379 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 92.45 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | 5.3406 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | -108.72 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 11.1853 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 5.8598 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 9.2178 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 2%/12%/52% | 72%/98%/100% | 0.4472 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.503 | 0.0 |
| wall_face | 58856 | 3%/12%/50% | 62%/86%/91% | 0.4365 | 0.902 | 0.0116 | grazing, 0.8953, 0.0664 | 0.4747 | 0.0 |
| ground_strip | 206971 | 15%/31%/59% | 16%/30%/58% | 0.0905 | 0.0 | 0.0905 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 1%/5%/24% | 11%/20%/38% | 0.4339 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7163 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0843, in own unknown voxels 0.7255, flagged generated 0.0.
