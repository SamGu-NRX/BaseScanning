# Geometry score: eth3d-facade/A2-da3L_images-posthoc-nonlidar_2018.draw0 vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-nonlidar_2018.draw0`. Status counts: {'scored': 35, 'missing': 15, 'extent_limited': 1, 'phantom': 12, 'scale_reference': 0}.

**Key distances (34 scored):** median 2.44 in, p90 8.21 in, max 35.92 in; ≤2 in 47%, ≤4 in 68%, ≤6 in 76%; within the recon's own bound 91%.

**Scale:** KD ratio median 0.97636 (n=8, error -2.364 %), landmark Umeyama 0.97606. Alignment: {'metric_declared': True, 'similarity_scale': 1.038084, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.669, 'camera_rms_m': 0.472, 'cameras': 16}.

**Anchor:** ICP translation 0.2798 m [-0.0317, 0.0288, 0.2765], yaw -1.031°, tilt 1.05°.

**On truly observed elements:** 26 KDs, median 2.44 in, p90 6.96 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4835 | -1.594 in | 0.194 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.8244 | -7.618 in | 0.614 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 90.11 | -1.0 deg | 44.7121 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 15.3814 | -18.449 in | 0.99 | True | – / – |
| `wall.length[w2]` | scored | 3.5426 | 2.6301 | -35.924 in | 0.562 | False | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -12.0145 | 7.949 in | 0.673 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.4784 | 7.102 in | 0.673 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0307 | 4.579 in | 0.673 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.4241 | 1.413 in | 0.673 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5361 | -0.846 in | 1.346 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.7069 | 8.315 in | 0.425 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.155 | 6.815 in | 0.425 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9594 | 3.303 in | 0.425 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4249 | -0.169 in | 0.425 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5519 | -1.5 in | 0.85 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.5315 | 5.276 in | 0.318 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.9488 | 3.709 in | 0.318 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9905 | 1.28 in | 0.318 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.4791 | -1.933 in | 0.318 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5827 | -1.567 in | 0.636 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4092 | 2.701 in | 0.272 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7714 | 0.461 in | 0.272 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0193 | 0.303 in | 0.272 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.4904 | -3.354 in | 0.272 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6378 | -2.24 in | 0.544 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7507 | -0.972 in | 0.294 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3212 | -3.602 in | 0.294 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0631 | -0.398 in | 0.294 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.5374 | -4.465 in | 0.294 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5705 | -2.63 in | 0.588 | True | partial / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.7715 | 1.213 in | 1.098 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6235 | -1.539 in | 0.743 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5396 | -1.008 in | 0.59 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5221 | -1.433 in | 0.566 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.871 | 22.126 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 1.03 | 28.15 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -12.557 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 92.97 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 5.4545 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -114.03 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 5.919 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 6.3899 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 6.2704 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 9.3616 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0635 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.2488 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 3.0912 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 3.9492 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 7%/28%/84% | 71%/98%/100% | 0.4273 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4368 | 0.0 |
| wall_face | 58856 | 7%/26%/78% | 61%/86%/92% | 0.4185 | 0.902 | 0.0106 | grazing, 0.8953, 0.0664 | 0.4188 | 0.0 |
| ground_strip | 206971 | 9%/28%/56% | 16%/30%/55% | 0.0834 | 0.0 | 0.0834 | unobserved, 0.0, 0.4654 | 0.0007 | 0.0007 |
| overhead | 1602 | 3%/8%/25% | 12%/22%/38% | 0.4815 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6812 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0798, in own unknown voxels 0.719, flagged generated 0.0.
