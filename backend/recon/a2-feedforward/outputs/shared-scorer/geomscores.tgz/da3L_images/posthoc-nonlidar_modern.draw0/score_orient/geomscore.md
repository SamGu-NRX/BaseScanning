# Geometry score: eth3d-facade/A2-da3L_images-posthoc-nonlidar_modern.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-nonlidar_modern.draw0-orient`. Status counts: {'scored': 29, 'missing': 21, 'extent_limited': 1, 'phantom': 3, 'scale_reference': 0}.

**Key distances (28 scored):** median 2.24 in, p90 21.15 in, max 35.71 in; ≤2 in 50%, ≤4 in 64%, ≤6 in 71%; within the recon's own bound 93%.

**Scale:** KD ratio median 0.97845 (n=7, error -2.155 %), landmark Umeyama 0.96091. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.1658 m [-0.0927, 0.021, 0.1358], yaw -0.155°, tilt 0.379°.

**On truly observed elements:** 21 KDs, median 1.98 in, p90 12.89 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4878 | -1.425 in | 0.192 | True | observed / observed |
| `corner.s[c1]` | scored | 3.0179 | 2.9864 | -1.24 in | 0.487 | True | – / – |
| `corner.turn[c1]` | scored | 91.11 | 93.5 | 2.39 deg | 36.2041 | True | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 11.135 | -185.63 in | 0.732 | False | – / – |
| `wall.length[w2]` | scored | 3.5426 | 2.9374 | -23.827 in | 0.632 | True | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.5434 | 4.807 in | 0.319 | True | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.9659 | 3.035 in | 0.319 | True | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9987 | 1.602 in | 0.319 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.4959 | -1.272 in | 0.319 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5775 | -1.772 in | 0.638 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4295 | 1.902 in | 0.268 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7852 | -0.083 in | 0.268 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0226 | 0.433 in | 0.268 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.5121 | -2.5 in | 0.268 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6443 | -1.984 in | 0.536 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7431 | -1.272 in | 0.29 | True | partial / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3389 | -2.906 in | 0.29 | True | partial / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.062 | -0.441 in | 0.29 | True | partial / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.5645 | -3.398 in | 0.29 | True | partial / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.5958 | -1.634 in | 0.58 | True | partial / observed |
| `opening.edge_s[door:left]` | scored | 7.2624 | 6.7542 | -20.008 in | 0.787 | True | unobserved / observed |
| `opening.edge_s[door:right]` | scored | 9.4522 | 9.7795 | 12.886 in | 0.787 | True | unobserved / observed |
| `opening.bottom[door]` | scored | 0.2116 | 0.0706 | -5.551 in | 0.787 | True | unobserved / observed |
| `opening.top[door]` | scored | 4.074 | 4.2347 | 6.327 in | 0.787 | True | unobserved / observed |
| `opening.width[door]` | scored | 2.1898 | 3.0253 | 32.894 in | 1.574 | True | unobserved / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5364 | -1.134 in | 0.587 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5283 | -1.189 in | 0.558 | True | – / – |
| `opening.gap[win5~door]` | scored | 4.8497 | 4.4153 | -17.102 in | 1.077 | True | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.726 | 16.417 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | scored | 0.315 | 1.222 | 35.709 in | 0.05 | False | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 5.9239 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -115.63 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 8.7465 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 22%/71%/98% | 72%/98%/100% | 0.3919 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3354 | 0.0 |
| wall_face | 58856 | 21%/64%/92% | 63%/87%/92% | 0.3862 | 0.902 | 0.0108 | grazing, 0.8953, 0.0664 | 0.3352 | 0.0023 |
| ground_strip | 206971 | 16%/32%/59% | 16%/31%/57% | 0.0896 | 0.0 | 0.0896 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 12%/21%/35% | 13%/21%/38% | 0.4107 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6415 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0536, in own unknown voxels 0.7342, flagged generated 0.0.
