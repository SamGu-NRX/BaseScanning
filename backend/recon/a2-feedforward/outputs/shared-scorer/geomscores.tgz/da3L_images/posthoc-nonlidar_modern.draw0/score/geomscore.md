# Geometry score: eth3d-facade/A2-da3L_images-posthoc-nonlidar_modern.draw0 vs eth3d-facade/gt-laser

Producer `A2-da3L_images-posthoc-nonlidar_modern.draw0`. Status counts: {'scored': 24, 'missing': 26, 'extent_limited': 1, 'phantom': 3, 'scale_reference': 0}.

**Key distances (24 scored):** median 1.99 in, p90 8.53 in, max 10.79 in; ≤2 in 50%, ≤4 in 75%, ≤6 in 83%; within the recon's own bound 100%.

**Scale:** KD ratio median 0.97657 (n=6, error -2.343 %), landmark Umeyama 0.97747. Alignment: {'metric_declared': True, 'similarity_scale': 1.038637, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.72, 'camera_rms_m': 0.4767, 'cameras': 16}.

**Anchor:** ICP translation 0.1225 m [-0.0336, 0.0339, 0.1128], yaw -0.272°, tilt 1.05°.

**On truly observed elements:** 21 KDs, median 2.05 in, p90 9.02 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4776 | -1.827 in | 0.205 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 13.2547 | -102.177 in | 1.014 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -11.9423 | 10.791 in | 0.68 | True | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -10.4296 | 9.024 in | 0.68 | True | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.023 | 4.276 in | 0.68 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.4081 | 0.783 in | 0.68 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.5127 | -1.768 in | 1.36 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.6787 | 9.425 in | 0.434 | True | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.1407 | 7.378 in | 0.434 | True | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9515 | 2.992 in | 0.434 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4169 | -0.484 in | 0.434 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.538 | -2.047 in | 0.868 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.5292 | 5.366 in | 0.327 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.9508 | 3.63 in | 0.327 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.9817 | 0.933 in | 0.327 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.4796 | -1.913 in | 0.327 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.5784 | -1.736 in | 0.654 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4127 | 2.563 in | 0.275 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7679 | 0.598 in | 0.275 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0099 | -0.067 in | 0.275 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.4997 | -2.988 in | 0.275 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6448 | -1.965 in | 0.55 | True | observed / observed |
| `opening.edge_s[win5:left]` | missing | 0.7754 |  |   |  |  | – / observed |
| `opening.edge_s[win5:right]` | missing | 2.4127 |  |   |  |  | – / observed |
| `opening.bottom[win5]` | missing | 1.0732 |  |   |  |  | – / observed |
| `opening.top[win5]` | missing | 3.6508 |  |   |  |  | – / observed |
| `opening.width[win5]` | missing | 1.6373 |  |   |  |  | – / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.7509 | 0.402 in | 1.114 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6115 | -2.012 in | 0.761 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5381 | -1.067 in | 0.602 | True | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | missing | 0.309 |  |   |  |  | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -12.6059 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 93.08 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 5.9372 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 34%/83%/99% | 70%/98%/100% | 0.3733 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3052 | 0.0 |
| wall_face | 58856 | 31%/74%/92% | 61%/86%/92% | 0.3737 | 0.902 | 0.0109 | grazing, 0.8953, 0.0664 | 0.309 | 0.0012 |
| ground_strip | 206971 | 10%/30%/58% | 16%/31%/57% | 0.0874 | 0.0 | 0.0874 | unobserved, 0.0, 0.4654 | 0.0008 | 0.0008 |
| overhead | 1602 | 13%/22%/30% | 13%/23%/38% | 0.4385 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6501 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.0681, in own unknown voxels 0.798, flagged generated 0.0.
