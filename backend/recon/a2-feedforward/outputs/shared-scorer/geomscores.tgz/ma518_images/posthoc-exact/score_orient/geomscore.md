# Geometry score: eth3d-facade/A2-ma518_images-posthoc-exact-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_images-posthoc-exact-orient`. Status counts: {'scored': 31, 'missing': 19, 'extent_limited': 1, 'phantom': 18, 'scale_reference': 0}.

**Key distances (31 scored):** median 5.72 in, p90 35.99 in, max 59.37 in; ≤2 in 13%, ≤4 in 23%, ≤6 in 52%; within the recon's own bound 74%.

**Scale:** KD ratio median 0.87996 (n=6, error -12.004 %), landmark Umeyama 0.87627. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.1789 m [0.0001, 0.1686, 0.06], yaw 0.166°, tilt 1.152°.

**On truly observed elements:** 26 KDs, median 5.41 in, p90 38.47 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4677 | -2.217 in | 0.196 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 25.1061 | 364.413 in | 1.05 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -10.7083 | 59.374 in | 0.894 | False | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -9.2625 | 54.972 in | 0.894 | False | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0902 | 6.921 in | 0.894 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.3299 | -2.295 in | 0.894 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | 1.4458 | -4.402 in | 1.788 | True | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -7.878 | 40.949 in | 0.886 | False | partial / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -6.414 | 35.988 in | 0.886 | False | partial / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 1.0116 | 5.358 in | 0.886 | True | partial / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.3249 | -4.106 in | 0.886 | True | partial / observed |
| `opening.width[win2]` | scored | 1.59 | 1.464 | -4.961 in | 1.772 | True | partial / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.1807 | 19.087 in | 0.341 | False | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.6879 | 13.98 in | 0.341 | False | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0394 | 3.205 in | 0.341 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.3829 | -5.72 in | 0.341 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.4928 | -5.106 in | 0.682 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.2919 | 7.319 in | 0.284 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7335 | 1.953 in | 0.284 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0323 | 0.815 in | 0.284 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.3669 | -8.217 in | 0.284 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.5584 | -5.366 in | 0.568 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.6703 | -4.138 in | 0.22 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.1692 | -9.587 in | 0.22 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0461 | -1.067 in | 0.22 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.3838 | -10.512 in | 0.22 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.4989 | -5.449 in | 0.44 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | scored | 1.7407 | 1.3845 | -14.024 in | 1.78 | True | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.2333 | -16.902 in | 1.227 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.396 | -6.661 in | 0.625 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.4038 | -6.091 in | 0.504 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.318 | 0.354 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | -31.0295 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -107.39 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -29.927 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 90.37 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -19.0711 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 62.83 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -11.5102 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 89.35 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 1.706 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 1.1024 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 10.856 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 7.5609 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 4.0939 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 6.8538 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.6258 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.7599 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.9247 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 21%/82%/96% | 73%/91%/98% | 0.5303 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4763 | 0.0 |
| wall_face | 58856 | 18%/70%/86% | 62%/79%/88% | 0.5129 | 0.902 | 0.015 | grazing, 0.8953, 0.0664 | 0.4523 | 0.0001 |
| ground_strip | 206971 | 3%/15%/26% | 6%/17%/26% | 0.1384 | 0.0 | 0.1384 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 2%/8%/14% | 1%/7%/24% | 0.5694 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6534 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.1656, in own unknown voxels 0.6769, flagged generated 0.0.
