# Geometry score: eth3d-facade/A2-ma518_images-shape vs eth3d-facade/gt-laser

Producer `A2-ma518_images-shape`. Status counts: {'scored': 7, 'missing': 43, 'extent_limited': 1, 'phantom': 6, 'scale_reference': 0}.

**Key distances (7 scored):** median 1.81 in, p90 11.32 in, max 14.18 in; ≤2 in 57%, ≤4 in 57%, ≤6 in 57%; within the recon's own bound 86%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama None. Alignment: {'metric_declared': False, 'similarity_scale': 1.411569, 'method': 'similarity (unscaled cloud): camera centres -> GT cameras; scale error not meaningful', 'camera_rms_m': 1.3175, 'cameras': 16}.

**Anchor:** ICP translation 0.4381 m [0.279, 0.2354, 0.2423], yaw -7.423°, tilt 6.878°.

**On truly observed elements:** 6 KDs, median 4.96 in, p90 11.8 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4943 | -1.169 in | 0.217 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 8.0976 | -305.213 in | 0.282 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | missing | -2.4778 |  |   |  |  | – / observed |
| `opening.edge_s[win4:right]` | missing | -0.7831 |  |   |  |  | – / observed |
| `opening.bottom[win4]` | missing | 1.0116 |  |   |  |  | – / observed |
| `opening.top[win4]` | missing | 3.5756 |  |   |  |  | – / observed |
| `opening.width[win4]` | missing | 1.6947 |  |   |  |  | – / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7922 | 0.661 in | 0.246 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.1902 | -8.76 in | 0.246 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.1 | 1.055 in | 0.246 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.2907 | -14.177 in | 0.246 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.398 | -9.421 in | 0.492 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.355 | 1.811 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.9208 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 6.279 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.3142 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.3582 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.7306 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 8%/23%/49% | 64%/83%/94% | 0.3844 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3606 | 0.0 |
| wall_face | 58856 | 8%/22%/46% | 54%/72%/85% | 0.3941 | 0.902 | 0.0163 | grazing, 0.8953, 0.0664 | 0.3549 | 0.0 |
| ground_strip | 206971 | 3%/13%/36% | 3%/9%/21% | 0.071 | 0.0 | 0.071 | unobserved, 0.0, 0.4654 | 0.0015 | 0.0015 |
| overhead | 1602 | 0%/0%/5% | 1%/6%/29% | 0.5384 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6078 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2219, in own unknown voxels 0.723, flagged generated 0.0.
