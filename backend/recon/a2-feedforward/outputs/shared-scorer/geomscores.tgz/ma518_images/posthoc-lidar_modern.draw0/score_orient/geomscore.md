# Geometry score: eth3d-facade/A2-ma518_images-posthoc-lidar_modern.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_images-posthoc-lidar_modern.draw0-orient`. Status counts: {'scored': 28, 'missing': 22, 'extent_limited': 1, 'phantom': 22, 'scale_reference': 0}.

**Key distances (28 scored):** median 119.61 in, p90 1320.06 in, max 1650.47 in; ≤2 in 14%, ≤4 in 21%, ≤6 in 36%; within the recon's own bound 46%.

**Scale:** KD ratio median 3.75626 (n=6, error 275.626 %), landmark Umeyama 0.88052. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.1844 m [-0.0047, 0.1736, 0.062], yaw 0.05°, tilt 1.204°.

**On truly observed elements:** 26 KDs, median 121.78 in, p90 1345.73 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4829 | -1.618 in | 0.206 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 25.3953 | 375.799 in | 1.064 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | scored | -12.2164 | -26.5623 | -564.799 in | 1.428 | False | unobserved / observed |
| `opening.edge_s[win1:right]` | scored | -10.6588 | -28.0181 | -683.437 in | 1.428 | False | unobserved / observed |
| `opening.bottom[win1]` | scored | 0.9144 | 1.0653 | 5.941 in | 1.428 | True | unobserved / observed |
| `opening.top[win1]` | scored | 3.3882 | 3.317 | -2.803 in | 1.428 | True | unobserved / observed |
| `opening.width[win1]` | scored | 1.5576 | -1.4558 | -118.638 in | 2.856 | False | unobserved / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -29.4116 | -806.831 in | 1.591 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -30.8846 | -927.421 in | 1.591 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.9973 | 4.795 in | 1.591 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.3222 | -4.213 in | 1.591 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | -1.473 | -120.591 in | 3.182 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -32.1251 | -1041.717 in | 1.206 | False | grazing / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -33.6261 | -1164.689 in | 1.206 | False | grazing / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0358 | 3.063 in | 1.206 | True | grazing / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.3903 | -5.429 in | 1.206 | True | grazing / observed |
| `opening.width[win3]` | scored | 1.6225 | -1.501 | -122.972 in | 2.412 | False | grazing / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -35.0292 | -1281.551 in | 1.325 | False | grazing / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -36.5948 | -1409.909 in | 1.325 | False | grazing / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0401 | 1.122 in | 1.325 | True | grazing / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.3848 | -7.512 in | 1.325 | True | grazing / observed |
| `opening.width[win4]` | scored | 1.6947 | -1.5656 | -128.358 in | 2.65 | False | grazing / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | -38.0047 | -1526.776 in | 1.352 | False | grazing / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | -39.5093 | -1650.472 in | 1.352 | False | grazing / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0655 | -0.303 in | 1.352 | True | grazing / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.4122 | -9.394 in | 1.352 | True | grazing / observed |
| `opening.width[win5]` | scored | 1.6373 | -1.5046 | -123.697 in | 2.704 | False | grazing / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.334 | 0.984 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.222 | -35.984 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -25.7295 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -88.44 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -18.6346 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 119.11 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -18.5016 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 60.6 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -11.7393 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 88.75 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 25.1904 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 7.095 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 0.133 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 6.7622 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | -41.4404 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | -44.2076 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.6727 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | -2.7672 |   |  |  | – / – |
| `opening.gap[rc:door~win5]` | phantom |  | 6.2029 |   |  |  | – / – |
| `opening.gap[win5~win4]` | phantom |  | 4.4801 |   |  |  | – / – |
| `opening.gap[win4~win3]` | phantom |  | 4.4697 |   |  |  | – / – |
| `opening.gap[win3~win2]` | phantom |  | 4.2145 |   |  |  | – / – |
| `opening.gap[win2~win1]` | phantom |  | 4.3223 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 23%/81%/96% | 71%/90%/98% | 0.4954 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4302 | 0.0 |
| wall_face | 58856 | 20%/70%/86% | 61%/78%/88% | 0.4848 | 0.902 | 0.0173 | grazing, 0.8953, 0.0664 | 0.4132 | 0.0 |
| ground_strip | 206971 | 4%/16%/27% | 6%/16%/27% | 0.1388 | 0.0 | 0.1388 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 1%/6%/13% | 0%/5%/24% | 0.5324 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.627 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.1648, in own unknown voxels 0.6881, flagged generated 0.0.
