# Geometry score: eth3d-facade/A2-ma518_images-posthoc-nonlidar_modern.draw0 vs eth3d-facade/gt-laser

Producer `A2-ma518_images-posthoc-nonlidar_modern.draw0`. Status counts: {'scored': 13, 'missing': 37, 'extent_limited': 1, 'phantom': 13, 'scale_reference': 0}.

**Key distances (13 scored):** median 35.79 in, p90 574.77 in, max 737.11 in; ≤2 in 23%, ≤4 in 31%, ≤6 in 31%; within the recon's own bound 46%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama 0.93183. Alignment: {'metric_declared': True, 'similarity_scale': 1.038678, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.724, 'camera_rms_m': 1.3781, 'cameras': 16}.

**Anchor:** ICP translation 0.5072 m [0.4125, 0.1685, 0.2423], yaw -5.602°, tilt 7.219°.

**On truly observed elements:** 11 KDs, median 120.47 in, p90 597.94 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4241 | -3.933 in | 0.221 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 6.3517 | -373.949 in | 0.63 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | 16.2447 | 737.106 in | 0.773 | False | grazing / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | 14.4046 | 597.941 in | 0.773 | False | grazing / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9755 | -1.421 in | 0.773 | True | grazing / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.3 | -10.85 in | 0.773 | True | grazing / observed |
| `opening.width[win4]` | scored | 1.6947 | -1.8401 | -139.165 in | 1.546 | False | grazing / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 13.0205 | 482.091 in | 0.642 | False | grazing / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 11.5979 | 361.622 in | 0.642 | False | grazing / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0407 | -1.28 in | 0.642 | True | grazing / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.1659 | -19.091 in | 0.642 | True | grazing / observed |
| `opening.width[win5]` | scored | 1.6373 | -1.4226 | -120.469 in | 1.284 | False | grazing / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.354 | 1.772 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.227 | -35.787 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | 5.6638 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 69.1 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 7.2825 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 124.8 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 1.6187 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 8.9455 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 9.9451 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 7.8562 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.028 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.9859 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | -2.0889 |   |  |  | – / – |
| `opening.gap[rc:door~win5]` | phantom |  | 5.1643 |   |  |  | – / – |
| `opening.gap[win5~win4]` | phantom |  | 4.6468 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 13%/30%/60% | 67%/84%/95% | 0.3861 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3542 | 0.0 |
| wall_face | 58856 | 12%/26%/54% | 57%/74%/86% | 0.4021 | 0.902 | 0.0213 | grazing, 0.8953, 0.0664 | 0.3494 | 0.0 |
| ground_strip | 206971 | 4%/16%/43% | 6%/15%/27% | 0.0865 | 0.0 | 0.0865 | unobserved, 0.0, 0.4654 | 0.0028 | 0.0028 |
| overhead | 1602 | 0%/0%/4% | 2%/5%/19% | 0.5291 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.58 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2148, in own unknown voxels 0.7004, flagged generated 0.0.
