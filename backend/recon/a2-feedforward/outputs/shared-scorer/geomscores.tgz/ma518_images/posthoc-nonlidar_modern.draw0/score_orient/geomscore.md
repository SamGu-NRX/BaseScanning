# Geometry score: eth3d-facade/A2-ma518_images-posthoc-nonlidar_modern.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_images-posthoc-nonlidar_modern.draw0-orient`. Status counts: {'scored': 8, 'missing': 42, 'extent_limited': 1, 'phantom': 12, 'scale_reference': 0}.

**Key distances (8 scored):** median 27.04 in, p90 384.62 in, max 470.5 in; ≤2 in 12%, ≤4 in 25%, ≤6 in 38%; within the recon's own bound 38%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama None. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.3286 m [0.0696, 0.1086, 0.3022], yaw -5.628°, tilt 0.75°.

**On truly observed elements:** 6 KDs, median 70.62 in, p90 409.16 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4093 | -4.516 in | 0.212 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 6.2143 | -379.358 in | 0.598 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | missing | -2.4778 |  |   |  |  | – / observed |
| `opening.edge_s[win4:right]` | missing | -0.7831 |  |   |  |  | – / observed |
| `opening.bottom[win4]` | missing | 1.0116 |  |   |  |  | – / observed |
| `opening.top[win4]` | missing | 3.5756 |  |   |  |  | – / observed |
| `opening.width[win4]` | missing | 1.6947 |  |   |  |  | – / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 12.7261 | 470.5 in | 0.611 | False | grazing / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 11.2471 | 347.811 in | 0.611 | False | grazing / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0242 | -1.929 in | 0.611 | True | grazing / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.1794 | -18.559 in | 0.611 | True | grazing / observed |
| `opening.width[win5]` | scored | 1.6373 | -1.479 | -122.689 in | 1.222 | False | grazing / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | missing | 1.5585 |  |   |  |  | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.405 | 3.78 in | 0.05 | False | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.234 | -35.512 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | 5.576 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 69.97 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 7.0256 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 125.95 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 1.4496 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 8.2363 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 9.554 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 7.4396 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0423 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.9999 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | -2.1144 |   |  |  | – / – |
| `opening.gap[rc:door~win5]` | phantom |  | 5.2865 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 18%/40%/76% | 73%/90%/98% | 0.4681 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.443 | 0.0 |
| wall_face | 58856 | 16%/35%/68% | 62%/77%/86% | 0.4592 | 0.902 | 0.0134 | grazing, 0.8953, 0.0664 | 0.4244 | 0.0 |
| ground_strip | 206971 | 4%/15%/30% | 7%/20%/26% | 0.1115 | 0.0 | 0.1115 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 0%/3%/5% | 3%/6%/20% | 0.5708 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6515 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.217, in own unknown voxels 0.6946, flagged generated 0.0.
