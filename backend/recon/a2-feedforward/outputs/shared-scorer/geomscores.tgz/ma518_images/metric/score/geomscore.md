# Geometry score: eth3d-facade/A2-ma518_images-metric vs eth3d-facade/gt-laser

Producer `A2-ma518_images-metric`. Status counts: {'scored': 18, 'missing': 32, 'extent_limited': 1, 'phantom': 13, 'scale_reference': 0}.

**Key distances (18 scored):** median 20.33 in, p90 45.49 in, max 48.49 in; ≤2 in 6%, ≤4 in 6%, ≤6 in 6%; within the recon's own bound 28%.

**Scale:** KD ratio median 1.0355 (n=2, error 3.55 %), landmark Umeyama 0.96651. Alignment: {'metric_declared': True, 'similarity_scale': 1.411569, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -29.157, 'camera_rms_m': 3.4265, 'cameras': 16}.

**Anchor:** ICP translation 0.574 m [0.5642, 0.0788, 0.0701], yaw 0.035°, tilt 7.659°.

**On truly observed elements:** 16 KDs, median 20.67 in, p90 45.63 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.0577 | -18.358 in | 0.177 | False | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 18.8949 | 119.878 in | 0.992 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.4861 | 7.063 in | 0.635 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.4581 | -16.343 in | 0.635 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 0.7328 | -8.866 in | 0.635 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 2.3781 | -45.28 in | 0.635 | False | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.028 | -23.406 in | 1.27 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.5482 | 36.598 in | 0.22 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.4529 | 13.0 in | 0.22 | False | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.7473 | -10.406 in | 0.22 | False | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.4075 | -45.988 in | 0.22 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.0953 | -23.598 in | 0.44 | False | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.5391 | -9.303 in | 0.182 | False | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.5926 | -32.287 in | 0.182 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 0.7572 | -12.441 in | 0.182 | False | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.4192 | -48.488 in | 0.182 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.0535 | -22.984 in | 0.364 | False | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 0.992 | -22.303 in | 0.402 | False | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.309 | 0.0 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `opening.edge_s[rc:win3:left]` | phantom |  | -3.5818 |   |  |  | – / – |
| `opening.edge_s[rc:win3:right]` | phantom |  | -2.5328 |   |  |  | – / – |
| `opening.bottom[rc:win3]` | phantom |  | 0.7524 |   |  |  | – / – |
| `opening.top[rc:win3]` | phantom |  | 2.4191 |   |  |  | – / – |
| `opening.width[rc:win3]` | phantom |  | 1.049 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 2.9483 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 4.8877 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.2961 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 1.9394 |   |  |  | – / – |
| `opening.gap[win3~rc:win3]` | phantom |  | 0.8763 |   |  |  | – / – |
| `opening.gap[rc:win3~win4]` | phantom |  | 0.9846 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.3557 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 40%/64%/80% | 60%/82%/96% | 0.3818 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3147 | 0.0 |
| wall_face | 58856 | 34%/56%/70% | 51%/71%/85% | 0.4018 | 0.902 | 0.0235 | grazing, 0.8953, 0.0664 | 0.3484 | 0.031 |
| ground_strip | 206971 | 7%/26%/58% | 9%/21%/36% | 0.0878 | 0.0 | 0.0878 | unobserved, 0.0, 0.4654 | 0.0109 | 0.0109 |
| overhead | 1602 | 0%/2%/5% | 0%/0%/7% | 0.5146 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.5384 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.1958, in own unknown voxels 0.6144, flagged generated 0.0.
