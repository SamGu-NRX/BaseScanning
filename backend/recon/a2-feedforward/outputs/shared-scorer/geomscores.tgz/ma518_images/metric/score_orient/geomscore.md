# Geometry score: eth3d-facade/A2-ma518_images-metric-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_images-metric-orient`. Status counts: {'scored': 14, 'missing': 36, 'extent_limited': 1, 'phantom': 18, 'scale_reference': 0}.

**Key distances (14 scored):** median 21.33 in, p90 44.57 in, max 50.55 in; ≤2 in 7%, ≤4 in 7%, ≤6 in 7%; within the recon's own bound 14%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama 0.63798. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.4193 m [0.049, 0.0649, 0.4113], yaw -3.664°, tilt 0.502°.

**On truly observed elements:** 11 KDs, median 23.13 in, p90 47.8 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.0413 | -19.004 in | 0.21 | False | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 7.6222 | -323.929 in | 0.504 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -1.6528 | 32.48 in | 0.249 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.5455 | 9.354 in | 0.249 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.7281 | -11.161 in | 0.249 | False | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 2.3616 | -47.795 in | 0.249 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.1073 | -23.126 in | 0.498 | False | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.4396 | -13.22 in | 0.215 | False | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 1.4718 | -37.043 in | 0.215 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 0.7567 | -12.461 in | 0.215 | False | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 2.3669 | -50.547 in | 0.215 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.0322 | -23.823 in | 0.43 | False | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 0.9851 | -22.575 in | 0.464 | False | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.312 | 0.118 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.626 | -20.079 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | 4.0945 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 74.46 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 5.5199 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 128.37 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 1.4254 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 6.2327 |   |  |  | – / – |
| `opening.edge_s[rc:win3:left]` | phantom |  | -3.7538 |   |  |  | – / – |
| `opening.edge_s[rc:win3:right]` | phantom |  | -2.6607 |   |  |  | – / – |
| `opening.bottom[rc:win3]` | phantom |  | 0.7131 |   |  |  | – / – |
| `opening.top[rc:win3]` | phantom |  | 2.3787 |   |  |  | – / – |
| `opening.width[rc:win3]` | phantom |  | 1.0931 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 7.603 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 6.0317 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0442 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 2.964 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | -1.5713 |   |  |  | – / – |
| `opening.gap[rc:win3~win4]` | phantom |  | 1.0079 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 6.1312 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 13%/36%/66% | 60%/85%/94% | 0.5035 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4414 | 0.0 |
| wall_face | 58856 | 11%/32%/58% | 51%/74%/83% | 0.4988 | 0.902 | 0.0236 | grazing, 0.8953, 0.0664 | 0.4504 | 0.0273 |
| ground_strip | 206971 | 5%/17%/31% | 9%/19%/32% | 0.1019 | 0.0 | 0.1019 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 2%/5%/5% | 1%/3%/14% | 0.5919 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.6488 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2174, in own unknown voxels 0.6346, flagged generated 0.0.
