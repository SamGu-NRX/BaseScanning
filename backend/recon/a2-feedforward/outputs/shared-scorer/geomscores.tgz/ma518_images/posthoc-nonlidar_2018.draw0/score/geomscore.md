# Geometry score: eth3d-facade/A2-ma518_images-posthoc-nonlidar_2018.draw0 vs eth3d-facade/gt-laser

Producer `A2-ma518_images-posthoc-nonlidar_2018.draw0`. Status counts: {'scored': 25, 'missing': 25, 'extent_limited': 1, 'phantom': 25, 'scale_reference': 0}.

**Key distances (25 scored):** median 9.05 in, p90 35.0 in, max 50.49 in; ≤2 in 12%, ≤4 in 24%, ≤6 in 24%; within the recon's own bound 64%.

**Scale:** KD ratio median 0.98045 (n=4, error -1.955 %), landmark Umeyama 1.09525. Alignment: {'metric_declared': True, 'similarity_scale': 1.039009, 'method': 'rigid (metric cloud): camera centres -> GT cameras', 'cloud_scale_error_pct': -3.754, 'camera_rms_m': 1.3791, 'cameras': 16}.

**Anchor:** ICP translation 0.5097 m [0.4082, 0.1598, 0.2601], yaw 0.721°, tilt 7.087°.

**On truly observed elements:** 21 KDs, median 9.05 in, p90 34.52 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4417 | -3.24 in | 0.216 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 24.6944 | 348.205 in | 1.088 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -9.9495 | -40.606 in | 0.839 | False | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -8.6105 | -50.488 in | 0.839 | False | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 1.1006 | 8.862 in | 0.839 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.2228 | -8.126 in | 0.839 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.339 | -9.882 in | 1.678 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -4.7888 | 34.516 in | 0.342 | False | partial / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -3.3926 | 25.606 in | 0.342 | False | partial / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0428 | 3.339 in | 0.342 | True | partial / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.2708 | -10.134 in | 0.342 | True | partial / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.3962 | -8.909 in | 0.684 | True | partial / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.0761 | 15.815 in | 0.301 | False | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.6114 | 6.76 in | 0.301 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0279 | 0.642 in | 0.301 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.2525 | -12.72 in | 0.301 | False | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.4647 | -9.055 in | 0.602 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7209 | -2.146 in | 0.237 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.137 | -10.854 in | 0.237 | False | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0329 | -1.587 in | 0.237 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.2659 | -15.154 in | 0.237 | False | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.4161 | -8.709 in | 0.474 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.3165 | -9.791 in | 0.643 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.3323 | -8.906 in | 0.538 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.345 | 1.417 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.239 | -35.315 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -30.7194 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | 141.93 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -23.7764 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | 110.4 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -18.5582 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | 115.65 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -11.3196 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 86.16 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 8.0557 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 6.9428 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 5.2182 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 7.2385 |   |  |  | – / – |
| `opening.edge_s[rc:win2:left]` | phantom |  | -7.318 |   |  |  | – / – |
| `opening.edge_s[rc:win2:right]` | phantom |  | -5.9551 |   |  |  | – / – |
| `opening.bottom[rc:win2]` | phantom |  | 1.0209 |   |  |  | – / – |
| `opening.top[rc:win2]` | phantom |  | 3.2169 |   |  |  | – / – |
| `opening.width[rc:win2]` | phantom |  | 1.3629 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 3.9655 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 6.5923 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.4465 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.6268 |   |  |  | – / – |
| `opening.gap[win2~rc:win2]` | phantom |  | 1.2925 |   |  |  | – / – |
| `opening.gap[rc:win2~win3]` | phantom |  | 1.1663 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 1.8285 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 4%/15%/48% | 64%/84%/96% | 0.385 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.3769 | 0.0 |
| wall_face | 58856 | 4%/13%/44% | 55%/74%/86% | 0.4004 | 0.902 | 0.022 | grazing, 0.8953, 0.0664 | 0.3865 | 0.0165 |
| ground_strip | 206971 | 4%/17%/47% | 5%/14%/27% | 0.0991 | 0.0 | 0.0991 | unobserved, 0.0, 0.4654 | 0.0059 | 0.0059 |
| overhead | 1602 | 1%/3%/8% | 1%/5%/20% | 0.4901 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.5933 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2015, in own unknown voxels 0.6814, flagged generated 0.0.
