# Geometry score: eth3d-facade/A2-ma518_images-posthoc-nonlidar_2018.draw0-orient vs eth3d-facade/gt-laser

Producer `A2-ma518_images-posthoc-nonlidar_2018.draw0-orient`. Status counts: {'scored': 13, 'missing': 37, 'extent_limited': 1, 'phantom': 24, 'scale_reference': 0}.

**Key distances (13 scored):** median 2.51 in, p90 9.15 in, max 19.05 in; ≤2 in 38%, ≤4 in 85%, ≤6 in 85%; within the recon's own bound 100%.

**Scale:** KD ratio median None (n=0, error None %), landmark Umeyama 0.97847. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.1491 m [0.0775, 0.0753, 0.1027], yaw -19.768°, tilt 0.705°.

**On truly observed elements:** 11 KDs, median 2.51 in, p90 10.5 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4295 | -3.72 in | 0.217 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 9.1979 | -261.894 in | 0.698 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | missing | -8.9181 |  |   |  |  | – / observed |
| `opening.edge_s[win2:right]` | missing | -7.3281 |  |   |  |  | – / observed |
| `opening.bottom[win2]` | missing | 0.8755 |  |   |  |  | – / observed |
| `opening.top[win2]` | missing | 3.4292 |  |   |  |  | – / observed |
| `opening.width[win2]` | missing | 1.59 |  |   |  |  | – / observed |
| `opening.edge_s[win3:left]` | missing | -5.6655 |  |   |  |  | – / observed |
| `opening.edge_s[win3:right]` | missing | -4.043 |  |   |  |  | – / observed |
| `opening.bottom[win3]` | missing | 0.958 |  |   |  |  | – / observed |
| `opening.top[win3]` | missing | 3.5282 |  |   |  |  | – / observed |
| `opening.width[win3]` | missing | 1.6225 |  |   |  |  | – / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.5414 | -2.504 in | 0.357 | True | partial / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.7577 | 1.0 in | 0.357 | True | partial / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 0.9944 | -0.677 in | 0.357 | True | partial / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.3088 | -10.504 in | 0.357 | True | partial / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.7837 | 3.504 in | 0.714 | True | partial / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.7096 | -2.591 in | 0.95 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3489 | -2.512 in | 0.95 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0561 | -0.673 in | 0.95 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.1668 | -19.055 in | 0.95 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6393 | 0.079 in | 1.9 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | missing | 1.6626 |  |   |  |  | – / – |
| `opening.gap[win3~win4]` | missing | 1.5652 |  |   |  |  | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.4673 | -3.591 in | 1.307 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.317 | 0.315 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | missing | 2.136 |  |   |  |  | – / – |
| `corner.s[rc:c1]` | phantom |  | 7.0556 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -66.07 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | 10.4388 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -145.39 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | 16.8343 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -81.14 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | 18.0712 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | -103.23 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | 21.1943 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | -83.61 |   |  |  | – / – |
| `corner.s[rc:c6]` | phantom |  | 22.3462 |   |  |  | – / – |
| `corner.turn[rc:c6]` | phantom |  | -75.26 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 3.3832 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 6.3955 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 1.2369 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 3.1232 |   |  |  | – / – |
| `wall.length[rc:w6]` | phantom |  | 1.1518 |   |  |  | – / – |
| `wall.length[rc:w7]` | phantom |  | 5.0243 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 18.6635 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 20.859 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.1129 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 3.9084 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.1955 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 16.3146 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 8%/18%/31% | 73%/90%/98% | 0.2607 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.2547 | 0.0 |
| wall_face | 58856 | 7%/17%/29% | 62%/77%/87% | 0.2856 | 0.902 | 0.0168 | grazing, 0.8953, 0.0664 | 0.2654 | 0.0 |
| ground_strip | 206971 | 5%/15%/24% | 7%/19%/27% | 0.0957 | 0.0 | 0.0957 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 1%/3%/5% | 1%/7%/20% | 0.5119 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.5794 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.2128, in own unknown voxels 0.6967, flagged generated 0.0.
