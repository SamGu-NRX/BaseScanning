# Geometry score: eth3d-facade/A2-da3L_KT-exact-metric-orient vs eth3d-facade/gt-laser

Producer `A2-da3L_KT-exact-metric-orient`. Status counts: {'scored': 26, 'missing': 24, 'extent_limited': 1, 'phantom': 27, 'scale_reference': 0}.

**Key distances (26 scored):** median 0.68 in, p90 2.85 in, max 24.61 in; ≤2 in 85%, ≤4 in 96%, ≤6 in 96%; within the recon's own bound 96%.

**Scale:** KD ratio median 0.99849 (n=4, error -0.151 %), landmark Umeyama 0.99599. Alignment: {'metric_declared': True, 'method': 'given transform'}.

**Anchor:** ICP translation 0.4455 m [-0.0065, 0.0339, 0.4442], yaw -2.205°, tilt 0.17°.

**On truly observed elements:** 21 KDs, median 0.69 in, p90 2.73 in. Elements the recon would claim observed but the truth grades grazing/unobserved: none.

| Key distance | Status | GT | Recon | Error | ± own | within | coverage claimed / truth |
|---|---|---|---|---|---|---|---|
| `meter.height` | scored | 1.524 | 1.4997 | -0.957 in | 0.192 | True | observed / observed |
| `corner.s[c1]` | missing | 3.0179 |  |   |  |  | – / – |
| `corner.turn[c1]` | missing | 91.11 |  |   |  |  | – / – |
| `corner.s[c2]` | missing | 6.5604 |  |   |  |  | – / – |
| `corner.turn[c2]` | missing | -91.08 |  |   |  |  | – / – |
| `wall.length[w1]` | extent_limited | 15.85 | 22.5577 | 264.083 in | 0.994 | False | – / – |
| `wall.length[w2]` | missing | 3.5426 |  |   |  |  | – / – |
| `wall.length[w3]` | missing | 4.9485 |  |   |  |  | – / – |
| `opening.edge_s[win1:left]` | missing | -12.2164 |  |   |  |  | – / observed |
| `opening.edge_s[win1:right]` | missing | -10.6588 |  |   |  |  | – / observed |
| `opening.bottom[win1]` | missing | 0.9144 |  |   |  |  | – / observed |
| `opening.top[win1]` | missing | 3.3882 |  |   |  |  | – / observed |
| `opening.width[win1]` | missing | 1.5576 |  |   |  |  | – / observed |
| `opening.edge_s[win2:left]` | scored | -8.9181 | -8.922 | -0.154 in | 0.411 | True | unobserved / observed |
| `opening.edge_s[win2:right]` | scored | -7.3281 | -7.3247 | 0.134 in | 0.411 | True | unobserved / observed |
| `opening.bottom[win2]` | scored | 0.8755 | 0.951 | 2.972 in | 0.411 | True | unobserved / observed |
| `opening.top[win2]` | scored | 3.4292 | 3.4681 | 1.531 in | 0.411 | True | unobserved / observed |
| `opening.width[win2]` | scored | 1.59 | 1.5973 | 0.287 in | 0.822 | True | unobserved / observed |
| `opening.edge_s[win3:left]` | scored | -5.6655 | -5.6504 | 0.594 in | 0.313 | True | unobserved / observed |
| `opening.edge_s[win3:right]` | scored | -4.043 | -4.0327 | 0.406 in | 0.313 | True | unobserved / observed |
| `opening.bottom[win3]` | scored | 0.958 | 1.0036 | 1.795 in | 0.313 | True | unobserved / observed |
| `opening.top[win3]` | scored | 3.5282 | 3.5257 | -0.098 in | 0.313 | True | unobserved / observed |
| `opening.width[win3]` | scored | 1.6225 | 1.6177 | -0.189 in | 0.626 | True | unobserved / observed |
| `opening.edge_s[win4:left]` | scored | -2.4778 | -2.4754 | 0.094 in | 0.217 | True | observed / observed |
| `opening.edge_s[win4:right]` | scored | -0.7831 | -0.8003 | -0.677 in | 0.217 | True | observed / observed |
| `opening.bottom[win4]` | scored | 1.0116 | 1.0291 | 0.689 in | 0.217 | True | observed / observed |
| `opening.top[win4]` | scored | 3.5756 | 3.5331 | -1.673 in | 0.217 | True | observed / observed |
| `opening.width[win4]` | scored | 1.6947 | 1.6751 | -0.772 in | 0.434 | True | observed / observed |
| `opening.edge_s[win5:left]` | scored | 0.7754 | 0.739 | -1.433 in | 0.225 | True | observed / observed |
| `opening.edge_s[win5:right]` | scored | 2.4127 | 2.3434 | -2.728 in | 0.225 | True | observed / observed |
| `opening.bottom[win5]` | scored | 1.0732 | 1.0604 | -0.504 in | 0.225 | True | observed / observed |
| `opening.top[win5]` | scored | 3.6508 | 3.5663 | -3.327 in | 0.225 | True | observed / observed |
| `opening.width[win5]` | scored | 1.6373 | 1.6044 | -1.295 in | 0.45 | True | observed / observed |
| `opening.edge_s[door:left]` | missing | 7.2624 |  |   |  |  | – / observed |
| `opening.edge_s[door:right]` | missing | 9.4522 |  |   |  |  | – / observed |
| `opening.bottom[door]` | missing | 0.2116 |  |   |  |  | – / observed |
| `opening.top[door]` | missing | 4.074 |  |   |  |  | – / observed |
| `opening.width[door]` | missing | 2.1898 |  |   |  |  | – / observed |
| `opening.gap[win1~win2]` | missing | 1.7407 |  |   |  |  | – / – |
| `opening.gap[win2~win3]` | scored | 1.6626 | 1.6743 | 0.461 in | 0.724 | True | – / – |
| `opening.gap[win3~win4]` | scored | 1.5652 | 1.5573 | -0.311 in | 0.53 | True | – / – |
| `opening.gap[win4~win5]` | scored | 1.5585 | 1.5393 | -0.756 in | 0.442 | True | – / – |
| `opening.gap[win5~door]` | missing | 4.8497 |  |   |  |  | – / – |
| `facing.depth[w1@2.79]` | scored | 0.309 | 0.315 | 0.236 in | 0.05 | True | – / – |
| `facing.depth[w2@3.14]` | missing | 0.315 |  |   |  |  | – / – |
| `facing.depth[w3@6.68]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@6.93]` | missing | 0.749 |  |   |  |  | – / – |
| `facing.depth[w3@9.94]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.19]` | missing | 0.708 |  |   |  |  | – / – |
| `facing.depth[w3@10.44]` | missing | 0.708 |  |   |  |  | – / – |
| `overhead.clearance[w1@2.79]` | scored | 2.136 | 1.511 | -24.606 in | 0.05 | False | – / – |
| `corner.s[rc:c1]` | phantom |  | -39.264 |   |  |  | – / – |
| `corner.turn[rc:c1]` | phantom |  | -129.3 |   |  |  | – / – |
| `corner.s[rc:c2]` | phantom |  | -30.2837 |   |  |  | – / – |
| `corner.turn[rc:c2]` | phantom |  | -83.61 |   |  |  | – / – |
| `corner.s[rc:c3]` | phantom |  | -29.666 |   |  |  | – / – |
| `corner.turn[rc:c3]` | phantom |  | -92.06 |   |  |  | – / – |
| `corner.s[rc:c4]` | phantom |  | -18.3664 |   |  |  | – / – |
| `corner.turn[rc:c4]` | phantom |  | 51.71 |   |  |  | – / – |
| `corner.s[rc:c5]` | phantom |  | -12.7883 |   |  |  | – / – |
| `corner.turn[rc:c5]` | phantom |  | 93.06 |   |  |  | – / – |
| `wall.length[rc:w1]` | phantom |  | 5.9084 |   |  |  | – / – |
| `wall.length[rc:w2]` | phantom |  | 8.9804 |   |  |  | – / – |
| `wall.length[rc:w3]` | phantom |  | 0.6178 |   |  |  | – / – |
| `wall.length[rc:w4]` | phantom |  | 11.2996 |   |  |  | – / – |
| `wall.length[rc:w5]` | phantom |  | 5.578 |   |  |  | – / – |
| `opening.edge_s[rc:win1:left]` | phantom |  | -44.6337 |   |  |  | – / – |
| `opening.edge_s[rc:win1:right]` | phantom |  | -45.3203 |   |  |  | – / – |
| `opening.bottom[rc:win1]` | phantom |  | 1.298 |   |  |  | – / – |
| `opening.top[rc:win1]` | phantom |  | 2.6148 |   |  |  | – / – |
| `opening.width[rc:win1]` | phantom |  | -0.6866 |   |  |  | – / – |
| `opening.edge_s[rc:door:left]` | phantom |  | 4.4092 |   |  |  | – / – |
| `opening.edge_s[rc:door:right]` | phantom |  | 7.3748 |   |  |  | – / – |
| `opening.bottom[rc:door]` | phantom |  | 0.0 |   |  |  | – / – |
| `opening.top[rc:door]` | phantom |  | 4.9249 |   |  |  | – / – |
| `opening.width[rc:door]` | phantom |  | 2.9656 |   |  |  | – / – |
| `opening.gap[rc:win1~win2]` | phantom |  | 36.3983 |   |  |  | – / – |
| `opening.gap[win5~rc:door]` | phantom |  | 2.0658 |   |  |  | – / – |

| Region | GT samples | ≤5/10/20 cm declared | ≤5/10/20 cm after ICP | grid claims observed | truly seen | false observed (grid) | truth by rule (status, share, grazing-only) | recon claims by rule | false observed by rule |
|---|---|---|---|---|---|---|---|---|---|
| meter_wall | 49689 | 8%/31%/68% | 29%/74%/100% | 0.4805 | 0.9995 | 0.0 | observed, 0.9992, 0.0007 | 0.4844 | 0.0 |
| wall_face | 58856 | 8%/32%/66% | 28%/70%/97% | 0.4678 | 0.902 | 0.0108 | grazing, 0.8953, 0.0664 | 0.4583 | 0.0 |
| ground_strip | 206971 | 11%/37%/62% | 19%/35%/60% | 0.1364 | 0.0 | 0.1364 | unobserved, 0.0, 0.4654 | 0.0 | 0.0 |
| overhead | 1602 | 2%/15%/33% | 23%/57%/100% | 0.5086 | 1.0 | 0.0 | observed, 1.0, 0.0 | 0.7169 | 0.0 |

**Unobserved geometry** (recon points within 10.0 m): unseen by any input camera 0.13, in own unknown voxels 0.7171, flagged generated 0.0.
